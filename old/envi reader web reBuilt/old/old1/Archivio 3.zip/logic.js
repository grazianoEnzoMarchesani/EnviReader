// Funzione di utilità per selezionare elementi DOM in modo sicuro
function safeQuerySelector(selector) {
  const element = document.querySelector(selector);
  if (!element) {
      console.warn(`Elemento non trovato: ${selector}`);
  }
  return element;
}

// Costanti per i selettori
const SELECTORS = {
  dataGroupSelector: '#dataGroupSelector',
  dataSelector: '#dataSelector',
  openFilesetA: '#openFilesetA',
  openFilesetB: '#openFilesetB',
  timeSlider: '#timeSlider',
  sliderTitle: '.slider-title',
  incrementTimeBtn: '.slider-btn[aria-label="Increment time"]',
  decrementTimeBtn: '.slider-btn[aria-label="Decrement time"]',
  levelSlider: '#levelSlider',
  sectionXSlider: '#sectionXSlider',
  sectionYSlider: '#sectionYSlider',
  followTerrain: '#followTerrain',
  colorSchemeSelector: '#colorSchemeSelector',
  windOpacitySlider: '#windOpacitySlider',
  windAnimationSlider: '#windAnimationSlider',
  windDensitySlider: '#windDensitySlider',
  savePresetButton: '#savePreset',
  visualizationContainerA: '#visualizationContainerA',
  visualizationContainerB: '#visualizationContainerB'
};

// Struttura predefinita delle cartelle
const FILE_STRUCTURE = {
    ENVIObjects: {},
    atmosphere: {},
    biomet: {
      PET: {},
      PMV: {},
      SET: {},
      UTCI: {}
    },
    buildings: {
      BPS: {},
      dynamic: {},
      static: {}
    },
    inflow: {},
    inputData: {},
    log: {},
    radiation: {},
    receptors: {},
    soil: {},
    solaraccess: {
      facades: {},
      ground: {},
      points: {}
    },
    surface: {},
    vegetation: {
      dynamic: {},
      static: {}
    },
    windsectors: {}
  };



// Gestione dello stato dell'applicazione
const state = {
  filesetA: null,
  filesetB: null,
  currentTimeIndex: 0,
  isCongruent: true,
  edxVariables: [] // Unico array per entrambe le visualizzazioni
};

// Selettori DOM
const DOM = {
  selectDataGroup: safeQuerySelector(SELECTORS.dataGroupSelector),
  selectData: safeQuerySelector(SELECTORS.dataSelector),
  buttonFilesetA: safeQuerySelector(SELECTORS.openFilesetA),
  buttonFilesetB: safeQuerySelector(SELECTORS.openFilesetB),
  pathDisplayA: document.createElement('div'),
  pathDisplayB: document.createElement('div'),
  timeSlider: safeQuerySelector(SELECTORS.timeSlider),
  timeLabel: safeQuerySelector(SELECTORS.sliderTitle),
  timeIncrementBtn: safeQuerySelector(SELECTORS.incrementTimeBtn),
  timeDecrementBtn: safeQuerySelector(SELECTORS.decrementTimeBtn),
  levelSlider: safeQuerySelector(SELECTORS.levelSlider),
  sectionXSlider: safeQuerySelector(SELECTORS.sectionXSlider),
  sectionYSlider: safeQuerySelector(SELECTORS.sectionYSlider),
  visualizationContainerA: safeQuerySelector(SELECTORS.visualizationContainerA),
  visualizationContainerB: safeQuerySelector(SELECTORS.visualizationContainerB),
  followTerrainCheckbox: safeQuerySelector(SELECTORS.followTerrain),
  colorSchemeSelector: safeQuerySelector(SELECTORS.colorSchemeSelector),
  windOpacitySlider: safeQuerySelector(SELECTORS.windOpacitySlider),
  windAnimationSlider: safeQuerySelector(SELECTORS.windAnimationSlider),
  windDensitySlider: safeQuerySelector(SELECTORS.windDensitySlider),
  savePresetButton: safeQuerySelector(SELECTORS.savePresetButton)
};



// Funzioni di utilità
function createPathDisplay() {
  DOM.pathDisplayA.className = 'path-display';
  DOM.pathDisplayB.className = 'path-display';
  DOM.buttonFilesetA.insertAdjacentElement('afterend', DOM.pathDisplayA);
  DOM.buttonFilesetB.insertAdjacentElement('afterend', DOM.pathDisplayB);
}

function handleDirectorySelection() {
  return new Promise(resolve => {
      const input = document.createElement('input');
      input.type = 'file';
      input.webkitdirectory = input.directory = true;

      input.addEventListener('change', ({ target: { files } }) => {
          if (files.length === 0) return resolve(null);

          const directoryStructure = {};
          const rootDir = files[0].webkitRelativePath.split('/')[0];
          Array.from(files).forEach(file => {
              const parts = file.webkitRelativePath.split('/');
              let current = directoryStructure;
              parts.slice(1).forEach((part, index) => {
                  if (index === parts.length - 2) {
                      current.files = current.files || [];
                      current.files.push(file);
                  } else {
                      current[part] = current[part] || {};
                      current = current[part];
                  }
              });
          });
          resolve({ structure: directoryStructure, rootDir });
      });

      input.click();
  });
}

async function updateFileset(filesetKey) {
  const result = await handleDirectorySelection();
  if (result) {
      state[filesetKey] = result;
      updatePathDisplays();
      console.log(`${filesetKey} directory structure:`, result.structure);

      const edxFile = findEDXFile(result.structure);
      if (edxFile) {
          const edxInfo = await readEDXFile(edxFile);
          state.edxVariables = edxInfo.variableNames;
          populateVariableDropdown(edxInfo.variableNames);
      }

      updateTimeSlider();
  } else {
      console.log(`${filesetKey} non selezionato`);
  }
}

function updatePathDisplay(filesetKey) {
  const { rootDir } = state[filesetKey];
  const selectedPath = DOM.selectDataGroup.value;
  const fullPath = `${rootDir}/${selectedPath}`;
  DOM[`pathDisplay${filesetKey.slice(-1)}`].textContent = `Selected path: ${fullPath}`;
}

function updatePathDisplays() {
  const selectedPath = DOM.selectDataGroup.value;
  ['filesetA', 'filesetB'].forEach(filesetKey => {
      const fileset = state[filesetKey];
      if (fileset) {
          updatePathDisplay(filesetKey);
      }
  });
}

function populateDataGroupDropdown(structure = FILE_STRUCTURE, prefix = '') {
    if (!DOM.selectDataGroup) {
        console.error("Elemento select per il gruppo di dati non trovato!");
        return;
    }
  
    Object.entries(structure).forEach(([key, value]) => {
        const fullPath = prefix ? `${prefix}/${key}` : key;
  
        const option = document.createElement('option');
        option.value = option.textContent = fullPath;
        DOM.selectDataGroup.appendChild(option);
  
        if (value && typeof value === 'object' && !Array.isArray(value)) {
            populateDataGroupDropdown(value, fullPath);
        }
    });
  }

function getFilesInFolder(structure, path) {
  const parts = path.split('/');
  let current = structure;
  for (const part of parts) {
      if (current[part]) {
          current = current[part];
      } else {
          return [];
      }
  }
  return current.files || [];
}

function getFileCoupleSeries(files) {
  const regex = /^(.+)_(\d{4}-\d{2}-\d{2})_(\d{2}\.\d{2}\.\d{2})\.(EDT|EDX)$/;
  const filePairs = files.reduce((pairs, file) => {
      const match = file.name.match(regex);
      if (match) {
          const [, name, date, time, ext] = match;
          const key = `${name}_${date}_${time}`;
          pairs[key] = pairs[key] || {};
          pairs[key][ext] = file;
      }
      return pairs;
  }, {});

  return Object.values(filePairs)
      .filter(pair => pair.EDT && pair.EDX)
      .sort((a, b) => a.EDT.name.localeCompare(b.EDT.name));
}

function updateTimeSlider() {
  if (!DOM.selectDataGroup || !DOM.timeSlider || !DOM.timeLabel) {
      console.error("Elementi necessari per updateTimeSlider non trovati!");
      return;
  }

  const selectedPath = DOM.selectDataGroup.value;
  const { filesetA, filesetB } = state;

  let fileCoupleSeries = [];

  if (filesetA) {
      const filesA = getFilesInFolder(filesetA.structure, selectedPath);
      fileCoupleSeries = getFileCoupleSeries(filesA);
  }

  if (filesetB) {
      const filesB = getFilesInFolder(filesetB.structure, selectedPath);
      const fileSeriesB = getFileCoupleSeries(filesB);
      fileCoupleSeries = fileCoupleSeries.length > fileSeriesB.length ? fileCoupleSeries : fileSeriesB;
  }

  if (fileCoupleSeries.length > 0) {
      DOM.timeSlider.min = 0;
      DOM.timeSlider.max = fileCoupleSeries.length - 1;
      DOM.timeSlider.value = 0;
      updateTimeLabel(fileCoupleSeries[0].EDT.name);
  } else {
      DOM.timeSlider.min = 0;
      DOM.timeSlider.max = 0;
      DOM.timeSlider.value = 0;
      DOM.timeLabel.innerHTML = '<span style="font-weight: bold;">Time</span> <span style="font-weight: 300;">No valid files</span>';
  }
  updateTimeButtons();
}

function updateTimeLabel(filename) {
  const match = filename.match(/_(\d{4}-\d{2}-\d{2})_(\d{2}\.\d{2}\.\d{2})/);
  if (match) {
      const [, date, time] = match;
      DOM.timeLabel.innerHTML = `<span style="font-weight: bold;">Time</span> <span style="font-weight: 300;">${date} - ${time.replace(/\./g, ':')}</span>`;
  } else {
      DOM.timeLabel.innerHTML = '<span style="font-weight: bold;">Time</span> <span style="font-weight: 300;">Invalid format</span>';
  }
}

function getFullPath(fileset, selectedPath, filename) {
  return `${fileset.rootDir}/${selectedPath}/${filename}`;
}

function updateTimeButtons() {
  if (!DOM.timeDecrementBtn || !DOM.timeIncrementBtn || !DOM.timeSlider) {
      console.error("Elementi necessari per updateTimeButtons non trovati!");
      return;
  }
  DOM.timeDecrementBtn.disabled = parseInt(DOM.timeSlider.value) <= parseInt(DOM.timeSlider.min);
  DOM.timeIncrementBtn.disabled = parseInt(DOM.timeSlider.value) >= parseInt(DOM.timeSlider.max);
}

function incrementTime() {
  if (!DOM.timeSlider) {
      console.error("Elemento timeSlider non trovato!");
      return;
  }
  const currentValue = parseInt(DOM.timeSlider.value);
  const maxValue = parseInt(DOM.timeSlider.max);
  if (currentValue < maxValue) {
      DOM.timeSlider.value = currentValue + 1;
      DOM.timeSlider.dispatchEvent(new Event('input'));
  }
}

function decrementTime() {
  if (!DOM.timeSlider) {
      console.error("Elemento timeSlider non trovato!");
      return;
  }
  const currentValue = parseInt(DOM.timeSlider.value);
  const minValue = parseInt(DOM.timeSlider.min);
  if (currentValue > minValue) {
      DOM.timeSlider.value = currentValue - 1;
      DOM.timeSlider.dispatchEvent(new Event('input'));
  }
}

function handleDataGroupChange() {
  updateTimeSlider();
  updateTimeButtons();
  updatePathDisplays();
  updateDataMenu();

  if (state.filesetA && state.filesetA.edxData) logExtractedValues('filesetA');
  if (state.filesetB && state.filesetB.edxData) logExtractedValues('filesetB');
}

function addEventListeners() {
  if (DOM.buttonFilesetA) {
      DOM.buttonFilesetA.addEventListener('click', () => {
          updateFileset('filesetA');
      });
  }

  if (DOM.buttonFilesetB) {
      DOM.buttonFilesetB.addEventListener('click', () => {
          updateFileset('filesetB');
      });
  }

  if (DOM.selectDataGroup) {
      DOM.selectDataGroup.addEventListener('change', handleDataGroupChange);
  }

  if (DOM.timeSlider) {
      DOM.timeSlider.addEventListener('input', handleTimeSliderInput);
      DOM.timeSlider.addEventListener('change', () => {
          updateTimeButtons();
      });
  }

  if (DOM.timeIncrementBtn) {
      DOM.timeIncrementBtn.addEventListener('click', incrementTime);
  }

  if (DOM.timeDecrementBtn) {
      DOM.timeDecrementBtn.addEventListener('click', decrementTime);
  }

  if (DOM.selectData) {
      DOM.selectData.addEventListener('change', () => {
          console.log("Variabile selezionata:", DOM.selectData.value);
          updateVisualization('filesetA');
          updateVisualization('filesetB');
      });
  }

  if (DOM.levelSlider) {
      DOM.levelSlider.addEventListener('input', handleLevelSliderInput);
  }

  if (DOM.sectionXSlider) {
      DOM.sectionXSlider.addEventListener('input', handleSectionXSliderInput);
  }

  if (DOM.sectionYSlider) {
      DOM.sectionYSlider.addEventListener('input', handleSectionYSliderInput);
  }

  if (DOM.followTerrainCheckbox) {
      DOM.followTerrainCheckbox.addEventListener('change', handleFollowTerrainChange);
  }

  if (DOM.colorSchemeSelector) {
      DOM.colorSchemeSelector.addEventListener('change', handleColorSchemeChange);
  }

  if (DOM.windOpacitySlider) {
      DOM.windOpacitySlider.addEventListener('input', handleWindOpacityChange);
  }

  if (DOM.windAnimationSlider) {
      DOM.windAnimationSlider.addEventListener('input', handleWindAnimationChange);
  }

  if (DOM.windDensitySlider) {
      DOM.windDensitySlider.addEventListener('input', handleWindDensityChange);
  }

  if (DOM.savePresetButton) {
      DOM.savePresetButton.addEventListener('click', handleSavePreset);
  }
}

async function handleTimeSliderInput() {
  const selectedPath = DOM.selectDataGroup.value;
  const { filesetA, filesetB } = state;

  let selectedCoupleA, selectedCoupleB;

  if (filesetA) {
      const filesA = getFilesInFolder(filesetA.structure, selectedPath);
      const fileSeriesA = getFileCoupleSeries(filesA);
      selectedCoupleA = fileSeriesA[DOM.timeSlider.value];
      if (selectedCoupleA) {
          updateTimeLabel(selectedCoupleA.EDT.name);
      }
  }

  if (filesetB) {
      const filesB = getFilesInFolder(filesetB.structure, selectedPath);
      const fileSeriesB = getFileCoupleSeries(filesB);
      selectedCoupleB = fileSeriesB[DOM.timeSlider.value];
      if (selectedCoupleB && !selectedCoupleA) {
          updateTimeLabel(selectedCoupleB.EDT.name);
      }
  }

  logSelectedFileCouples(selectedPath, selectedCoupleA, selectedCoupleB, filesetA, filesetB);
  updateTimeButtons();

  if (state.filesetA && state.filesetA.edxData) logExtractedValues('filesetA');
  if (state.filesetB && state.filesetB.edxData) logExtractedValues('filesetB');

  await updateVisualization('filesetA');
  await updateVisualization('filesetB');
}

function logSelectedFileCouples(selectedPath, selectedCoupleA, selectedCoupleB, filesetA, filesetB) {
  console.log('Selected file couples:');

  if (selectedCoupleA) {
      const edtPathA = getFullPath(filesetA, selectedPath, selectedCoupleA.EDT.name);
      const edxPathA = getFullPath(filesetA, selectedPath, selectedCoupleA.EDX.name);
      console.log('Fileset A:');
      console.log(`EDT: ${edtPathA}`);
      console.log(`EDX: ${edxPathA}`);
  } else if (filesetA) {
      console.log('Fileset A: No matching files for this time step');
  }

  if (selectedCoupleB) {
      const edtPathB = getFullPath(filesetB, selectedPath, selectedCoupleB.EDT.name);
      const edxPathB = getFullPath(filesetB, selectedPath, selectedCoupleB.EDX.name);
      console.log('Fileset B:');
      console.log(`EDT: ${edtPathB}`);
      console.log(`EDX: ${edxPathB}`);
  } else if (filesetB) {
      console.log('Fileset B: No matching files for this time step');
  }
}

async function processEDXFile(file, filesetKey) {
  try {
      const content = await readFileContent(file);
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(content, "text/xml");

      const nrXData = parseInt(xmlDoc.querySelector("nr_xdata").textContent);
      const nrYData = parseInt(xmlDoc.querySelector("nr_ydata").textContent);
      const nrZData = parseInt(xmlDoc.querySelector("nr_zdata").textContent);

      const spacingX = processSpacingData(xmlDoc.querySelector("spacing_x").textContent);
      const spacingY = processSpacingData(xmlDoc.querySelector("spacing_y").textContent);
      const spacingZ = processSpacingData(xmlDoc.querySelector("spacing_z").textContent);

      state[filesetKey].edxData = {
          nrXData, nrYData, nrZData, spacingX, spacingY, spacingZ
      };

      checkCongruence();

      logExtractedValues(filesetKey);
  } catch (error) {
      console.error(`Errore nel processare il file EDX per ${filesetKey}:`, error);
  }
}

function readFileContent(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (event) => {
            const arrayBuffer = event.target.result;
            try {
                const content = new TextDecoder('Windows-1252').decode(arrayBuffer);
                if (content.includes('<name_variables>')) {
                    console.log('Codifica utilizzata: Windows-1252');
                    resolve(content);
                } else {
                    reject(new Error("Il contenuto del file non sembra essere nel formato atteso"));
                }
            } catch (e) {
                console.error('Errore nella decodifica del file:', e);
                reject(e);
            }
        };
        reader.onerror = (error) => reject(error);
        reader.readAsArrayBuffer(file);
    });
}

function processSpacingData(spacingString) {
  return spacingString.split(',')
      .map(num => parseFloat(num.trim()))
      .map(num => Number(num.toFixed(2)));
}

function checkCongruence() {
  if (state.filesetA && state.filesetB && state.filesetA.edxData && state.filesetB.edxData) {
      const dataA = state.filesetA.edxData;
      const dataB = state.filesetB.edxData;

      const isCongruent =
          dataA.nrXData === dataB.nrXData &&
          dataA.nrYData === dataB.nrYData &&
          dataA.nrZData === dataB.nrZData &&
          arraysEqual(dataA.spacingX, dataB.spacingX) &&
          arraysEqual(dataA.spacingY, dataB.spacingY) &&
          arraysEqual(dataA.spacingZ, dataB.spacingZ);

      state.isCongruent = isCongruent;
      console.log(`I fileset sono ${isCongruent ? 'congruenti' : 'non congruenti'}`);
  }
}

function arraysEqual(a, b) {
  return a.length === b.length && a.every((val, index) => val === b[index]);
}

function logExtractedValues(filesetKey) {
  const data = state[filesetKey].edxData;
  console.log(`Valori estratti per ${filesetKey}:`);
  console.log(`nr_xdata: ${data.nrXData}`);
  console.log(`nr_ydata: ${data.nrYData}`);
  console.log(`nr_zdata: ${data.nrZData}`);
  console.log(`spacing_x: ${data.spacingX.join(', ')}`);
  console.log(`spacing_y: ${data.spacingY.join(', ')}`);
  console.log(`spacing_z: ${data.spacingZ.join(', ')}`);
}

function findEDXFile(structure) {
  for (const key in structure) {
      if (structure[key] && typeof structure[key] === 'object') {
          if (Array.isArray(structure[key].files)) {
              const edxFile = structure[key].files.find(file => file.name.endsWith('.EDX'));
              if (edxFile) {
                  return edxFile;
              }
          }
          const result = findEDXFile(structure[key]);
          if (result) {
              return result;
          }
      }
  }
  return null;
}

async function readEDXFile(file) {
    const content = await readFileContent(file);
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(content, "text/xml");

    const decodeText = (text) => {
        const textarea = document.createElement('textarea');
        textarea.innerHTML = text;
        return textarea.value;
    };

    const variableNames = xmlDoc.querySelector("name_variables").textContent
        .split(',')
        .map(name => decodeText(name.trim()));

    const nrVariables = parseInt(xmlDoc.querySelector("nr_variables").textContent);
    const dimensions = {
        x: parseInt(xmlDoc.querySelector("nr_xdata").textContent),
        y: parseInt(xmlDoc.querySelector("nr_ydata").textContent),
        z: parseInt(xmlDoc.querySelector("nr_zdata").textContent)
    };

    return { variableNames, nrVariables, dimensions };
}

async function readEDTFile(file, edxInfo, selectedVariable, sliceConfig) {
  const buffer = await file.arrayBuffer();
  const dataView = new DataView(buffer);

  const { dimensions, nrVariables, variableNames } = edxInfo;
  const variableIndex = variableNames.indexOf(selectedVariable);

  if (variableIndex === -1) {
      throw new Error("Selected variable not found in EDX file");
  }

  const sliceData = extractSlice(dataView, dimensions, nrVariables, variableIndex, sliceConfig);

  return sliceData;
}

function extractSlice(dataView, dimensions, nrVariables, variableIndex, sliceConfig) {
  const { level, sectionX, sectionY } = sliceConfig;
  const sliceData = [];

  const bytesPerValue = 4; // Assumendo che i dati siano float a 32 bit
  const totalDataPoints = dimensions.x * dimensions.y * dimensions.z;
  const variableOffset = variableIndex * totalDataPoints * bytesPerValue;

  if (level !== null) {
      // Estrai slice orizzontale (XY)
      for (let y = 0; y < dimensions.y; y++) {
          for (let x = 0; x < dimensions.x; x++) {
              const offset = variableOffset + ((level * dimensions.y + y) * dimensions.x + x) * bytesPerValue;
              const value = dataView.getFloat32(offset, true);
              sliceData.push(value === -999 ? null : value);
          }
      }
  } else if (sectionX !== null) {
      // Estrai slice verticale (YZ)
      for (let z = 0; z < dimensions.z; z++) {
          for (let y = 0; y < dimensions.y; y++) {
              const offset = variableOffset + ((z * dimensions.y + y) * dimensions.x + sectionX) * bytesPerValue;
              const value = dataView.getFloat32(offset, true);
              sliceData.push(value === -999 ? null : value);
          }
      }
  } else if (sectionY !== null) {
      // Estrai slice verticale (XZ)
      for (let z = 0; z < dimensions.z; z++) {
          for (let x = 0; x < dimensions.x; x++) {
              const offset = variableOffset + ((z * dimensions.y + sectionY) * dimensions.x + x) * bytesPerValue;
              const value = dataView.getFloat32(offset, true);
              sliceData.push(value === -999 ? null : value);
          }
      }
  }

  return sliceData;
}

function populateVariableDropdown(variableNames) {
  const selectElement = DOM.selectData;
  if (!selectElement) {
      console.error(`Elemento select per i dati non trovato!`);
      return;
  }

  selectElement.innerHTML = '';
  variableNames.forEach(name => {
      const option = document.createElement('option');
      option.value = option.textContent = name;
      selectElement.appendChild(option);
  });

  console.log(`Menu a tendina 'Data' aggiornato con nuove variabili.`);
}

async function updateDataMenu() {
  const selectedPath = DOM.selectDataGroup.value;
  const { filesetA, filesetB } = state;

  let files = [];
  if (filesetA) files = files.concat(getFilesInFolder(filesetA.structure, selectedPath));
  if (filesetB) files = files.concat(getFilesInFolder(filesetB.structure, selectedPath));

  const fileSeries = getFileCoupleSeries(files);
  if (fileSeries.length > 0) {
      const edxFile = fileSeries[0].EDX;
      const edxInfo = await readEDXFile(edxFile);
      populateVariableDropdown(edxInfo.variableNames);
  } else {
      console.warn(`Nessun file EDX trovato per il percorso selezionato`);
      DOM.selectData.innerHTML = '<option value="">Nessun dato disponibile</option>';
  }
}

async function handleLevelSliderInput() {
  await updateVisualization('filesetA');
  await updateVisualization('filesetB');
}

async function handleSectionXSliderInput() {
  await updateVisualization('filesetA');
  await updateVisualization('filesetB');
}

async function handleSectionYSliderInput() {
  await updateVisualization('filesetA');
  await updateVisualization('filesetB');
}

function handleFollowTerrainChange() {
  console.log("Follow terrain:", DOM.followTerrainCheckbox.checked);
  updateVisualization('filesetA');
  updateVisualization('filesetB');
}

function handleColorSchemeChange() {
  console.log("Color scheme changed:", DOM.colorSchemeSelector.value);
  updateVisualization('filesetA');
  updateVisualization('filesetB');
}

function handleWindOpacityChange() {
  console.log("Wind opacity:", DOM.windOpacitySlider.value);
  updateVisualization('filesetA');
  updateVisualization('filesetB');
}

function handleWindAnimationChange() {
  console.log("Wind animation:", DOM.windAnimationSlider.value);
  updateVisualization('filesetA');
  updateVisualization('filesetB');
}

function handleWindDensityChange() {
  console.log("Wind density:", DOM.windDensitySlider.value);
  updateVisualization('filesetA');
  updateVisualization('filesetB');
}

function handleSavePreset() {
  console.log("Saving preset");
  // Implementare la logica per salvare il preset
}

async function updateVisualization(filesetKey) {
  const selectedVariable = DOM.selectData.value;
  const level = parseInt(DOM.levelSlider.value);
  const sectionX = parseInt(DOM.sectionXSlider.value);
  const sectionY = parseInt(DOM.sectionYSlider.value);
  const selectedPath = DOM.selectDataGroup.value;

  const fileset = state[filesetKey];
  if (!fileset) {
      console.error(`Fileset ${filesetKey} non trovato`);
      return;
  }

  let edtFile, edxInfo;
  const files = getFilesInFolder(fileset.structure, selectedPath);
  const fileSeries = getFileCoupleSeries(files);
  if (fileSeries.length > 0) {
      const currentTimeIndex = parseInt(DOM.timeSlider.value);
      edtFile = fileSeries[currentTimeIndex].EDT;
      edxInfo = await readEDXFile(fileSeries[currentTimeIndex].EDX);
  }

  if (edtFile && edxInfo) {
      // Crea tre slice config, uno per ogni vista
      const levelSliceConfig = { level, sectionX: null, sectionY: null };
      const sectionXSliceConfig = { level: null, sectionX, sectionY: null };
      const sectionYSliceConfig = { level: null, sectionX: null, sectionY };

      // Estrai i dati per ogni slice
      const levelSliceData = await readEDTFile(edtFile, edxInfo, selectedVariable, levelSliceConfig);
      const sectionXSliceData = await readEDTFile(edtFile, edxInfo, selectedVariable, sectionXSliceConfig);
      const sectionYSliceData = await readEDTFile(edtFile, edxInfo, selectedVariable, sectionYSliceConfig);

      // Visualizza i dati per ogni slice
      visualizeData(levelSliceData, edxInfo.dimensions, levelSliceConfig, selectedVariable, 'level', filesetKey);
      visualizeData(sectionXSliceData, edxInfo.dimensions, sectionXSliceConfig, selectedVariable, 'section-x', filesetKey);
      visualizeData(sectionYSliceData, edxInfo.dimensions, sectionYSliceConfig, selectedVariable, 'section-y', filesetKey);
  } else {
      console.error(`File EDT o informazioni EDX non disponibili per ${filesetKey}`);
  }
}

function visualizeData(sliceData, dimensions, sliceConfig, variableName, viewType, filesetKey) {
  const { level, sectionX, sectionY } = sliceConfig;

  // Crea un elemento canvas per la visualizzazione
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');

  let width, height;
  if (level !== null) {
      width = dimensions.x;
      height = dimensions.y;
  } else if (sectionX !== null) {
      width = dimensions.y;
      height = dimensions.z;
  } else if (sectionY !== null) {
      width = dimensions.x;
      height = dimensions.z;
  }

  canvas.width = width;
  canvas.height = height;

  // Trova il valore minimo e massimo nei dati, ignorando i valori nulli
  const validData = sliceData.filter(value => value !== null);
  const minValue = Math.min(...validData);
  const maxValue = Math.max(...validData);

  // Crea un'immagine dai dati
  const imageData = ctx.createImageData(width, height);
  for (let i = 0; i < sliceData.length; i++) {
      const value = sliceData[i];
      if (value === null) {
          // Usa un colore specifico per i valori nulli (ad esempio, grigio trasparente)
          imageData.data[i * 4] = 128;     // R
          imageData.data[i * 4 + 1] = 128; // G
          imageData.data[i * 4 + 2] = 128; // B
          imageData.data[i * 4 + 3] = 100; // A (semi-trasparente)
      } else {
          const normalizedValue = (value - minValue) / (maxValue - minValue);
          const colorValue = Math.floor(normalizedValue * 255);
          imageData.data[i * 4] = colorValue;     // R
          imageData.data[i * 4 + 1] = colorValue; // G
          imageData.data[i * 4 + 2] = colorValue; // B
          imageData.data[i * 4 + 3] = 255;        // A
      }
  }
  ctx.putImageData(imageData, 0, 0);

  // Mostra il canvas nell'interfaccia utente
  const containerSelector = `#visualizationContainer${filesetKey.slice(-1)} .chart-container.${viewType}`;
  const visualizationContainer = document.querySelector(containerSelector);
  if (visualizationContainer) {
      visualizationContainer.innerHTML = '';
      visualizationContainer.appendChild(canvas);

      // Aggiungi una legenda o informazioni sulla visualizzazione
      const infoDiv = document.createElement('div');
      infoDiv.textContent = `${variableName}, Min: ${minValue.toFixed(2)}, Max: ${maxValue.toFixed(2)}, Null values: ${sliceData.filter(v => v === null).length}`;
      visualizationContainer.appendChild(infoDiv);
  } else {
      console.error(`Container non trovato per la vista ${viewType} del ${filesetKey}`);
  }
}

function handleDataChange() {
    updateVisualization('filesetA');
    updateVisualization('filesetB');
}

// Inizializzazione
function init() {
    createPathDisplay();
    
    if (DOM.selectDataGroup) {
        populateDataGroupDropdown();
    } else {
        console.error("Elemento select per il gruppo di dati non trovato durante l'inizializzazione!");
    }

    if (DOM.timeSlider && DOM.selectDataGroup) {
        updateTimeSlider();
    } else {
        console.error("Elementi necessari per updateTimeSlider non trovati durante l'inizializzazione!");
    }

    addEventListeners();
    
    if (DOM.selectData) {
        DOM.selectData.innerHTML = '';
    } else {
        console.error("Elemento select per i dati non trovato durante l'inizializzazione!");
    }

    console.log("Elementi DOM trovati:", Object.keys(DOM).filter(key => DOM[key] !== null));
}

// Avvia l'inizializzazione quando il DOM è completamente caricato
document.addEventListener('DOMContentLoaded', init);

// Gestione del tema scuro/chiaro
document.addEventListener('DOMContentLoaded', () => {
    const themeSwitcher = document.getElementById('theme-icon');

    // Carica il tema salvato, se esiste
    const currentTheme = localStorage.getItem('theme') || 'light';
    document.body.classList.add(`${currentTheme}-mode`);
    themeSwitcher.classList.add(currentTheme === 'light' ? 'icon-sun' : 'icon-moon');

    themeSwitcher.addEventListener('click', () => {
        const isLight = document.body.classList.contains('light-mode');
        document.body.classList.toggle('light-mode', !isLight);
        document.body.classList.toggle('dark-mode', isLight);
        themeSwitcher.classList.toggle('icon-sun', !isLight);
        themeSwitcher.classList.toggle('icon-moon', isLight);

        // Salva il tema selezionato
        localStorage.setItem('theme', isLight ? 'dark' : 'light');
    });
});
