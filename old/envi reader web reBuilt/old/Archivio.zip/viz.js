import { DOM } from './enviropment.js';
import { state } from './enviropment.js';
import { chartInstances } from './enviropment.js';

import { getFileCoupleSeries } from './fileMan.js';
import { getFilesInFolder } from './fileMan.js';
import { readEDTFile } from './fileMan.js';
import { readEDXFile } from './processing.js';
import { changeSliderValue } from './utils.js';

import { handleTimeSliderChange } from './events.js';
import { visualizeData } from './viz2.js';
import { visualizeTimeSeries } from './viz2.js';
import { resizeChartContainers } from './viz2.js';


/************         Funzioni di visualizzazione         ************/
export function captureChartImage(chartKey) {
    return new Promise((resolve, reject) => {
        const chart = chartInstances[chartKey];
        if (!chart) {
            reject(new Error(`Chart non trovato per la chiave ${chartKey}`));
            return;
        }

        const container = chart.getDom().closest('.chart-container');
        if (!container) {
            reject(new Error('Container del chart non trovato'));
            return;
        }

        // Utilizziamo html2canvas per catturare l'intero container del chart
        html2canvas(container, {
            logging: false, // Disabilita il logging per migliorare le prestazioni
            useCORS: true, // Abilita CORS per le immagini esterne
            scale: window.devicePixelRatio // Usa il pixel ratio del dispositivo per una migliore qualità
        }).then(canvas => {
            resolve(canvas.toDataURL('image/png'));
        }).catch(error => {
            //console.error('Errore durante la cattura del chart:', error);
            reject(error);
        });
    });
}

export async function captureAllCharts() {
    const chartImages = [];
    for (const chartKey in chartInstances) {
        try {
            const imageDataUrl = await captureChartImage(chartKey);
            chartImages.push({ key: chartKey, dataUrl: imageDataUrl });
        } catch (error) {
            //console.error(`Errore nella cattura dell'immagine per ${chartKey}:`, error);
        }
    }
    return chartImages;
}


export function cleanupCharts(filesetKey) {
    const chartKeys = Object.keys(chartInstances).filter(key => key.startsWith(filesetKey));
    chartKeys.forEach(key => {
        if (chartInstances[key]) {
            chartInstances[key].dispose();
            delete chartInstances[key];
        }
    });
    if (filesetKey === 'filesetA' || filesetKey === 'filesetB') {
        if (chartInstances['timeSeries']) {
            chartInstances['timeSeries'].dispose();
            delete chartInstances['timeSeries'];
        }
    }
}
// Aggiorna la visualizzazione per un fileset
export async function updateVisualization(filesetKey, viewType = 'all') {
    //console.log(`Updating visualization for ${filesetKey}, viewType: ${viewType}`);
    const selectedVariable = DOM.selectData.value;
    const level = parseInt(DOM.levelSlider.value);
    const sectionX = parseInt(DOM.sectionXSlider.value);
    const sectionY = parseInt(DOM.sectionYSlider.value);
    const selectedPath = DOM.selectDataGroup.value;
    const fileset = state[filesetKey];
    if (!fileset) {
        //console.log(`Fileset ${filesetKey} non caricato`);
        return;
    }

    const files = getFilesInFolder(fileset.structure, selectedPath);
    const fileSeries = getFileCoupleSeries(files);
    if (fileSeries.length === 0) {
        //console.error(`Nessun file trovato per ${filesetKey}`);
        return;
    }

    const currentTimeIndex = parseInt(DOM.timeSlider.value);
    const edtFile = fileSeries[currentTimeIndex].EDT;
    const edxInfo = await readEDXFile(fileSeries[currentTimeIndex].EDX);

    if (!edtFile || !edxInfo) {
        //console.error(`File EDT o informazioni EDX non disponibili per ${filesetKey}`);
        return;
    }

    const { x: nrXData, y: nrYData, z: nrZData } = state.dimensions;
    //console.log( nrXData,nrYData, nrZData);
    const spacing = state[filesetKey].edxData.spacing;

    const terrainData = state[`terrainData${filesetKey.slice(-1)}`];

    const levelSliceConfig = { level, sectionX: null, sectionY: null, terrainData, spacing };
    const sectionXSliceConfig = { level: null, sectionX: Math.min(sectionX, nrXData - 1), sectionY: null, terrainData, spacing };
    const sectionYSliceConfig = { level: null, sectionX: null, sectionY: Math.min(sectionY, nrYData - 1), terrainData, spacing };

    if (viewType === 'all' || viewType === 'level') {
        const levelSliceData = await readEDTFile(edtFile, edxInfo, selectedVariable, levelSliceConfig);
        visualizeData(levelSliceData, state.dimensions, levelSliceConfig, selectedVariable, 'level', filesetKey);
    }

    if (viewType === 'all' || viewType === 'section-x') {
        const sectionXSliceData = await readEDTFile(edtFile, edxInfo, selectedVariable, sectionXSliceConfig);
        visualizeData(sectionXSliceData, state.dimensions, sectionXSliceConfig, selectedVariable, 'section-x', filesetKey);
    }

    if (viewType === 'all' || viewType === 'section-y') {
        const sectionYSliceData = await readEDTFile(edtFile, edxInfo, selectedVariable, sectionYSliceConfig);
        visualizeData(sectionYSliceData, state.dimensions, sectionYSliceConfig, selectedVariable, 'section-y', filesetKey);
    }

    if (state.filesetA && state.filesetB && filesetKey === 'filesetB') {
        await calculateAndVisualizeDifference(selectedVariable, levelSliceConfig, sectionXSliceConfig, sectionYSliceConfig, viewType);
    }


    resizeChartContainers();
    
    //console.log(`Visualization updated for ${filesetKey}`);
    if (filesetKey === 'filesetB' || (filesetKey === 'filesetA' && !state.filesetB)) {
        const selectedVariable = DOM.selectData.value;
        const selectedPath = DOM.selectDataGroup.value;
        
        const dataA = await readAllEDTFiles('filesetA', selectedPath, selectedVariable);
        const dataB = state.filesetB ? await readAllEDTFiles('filesetB', selectedPath, selectedVariable) : [];
        
        const timeSeriesData = prepareTimeSeriesData(dataA, dataB);
        visualizeTimeSeries(timeSeriesData, selectedVariable);
    }
}




// Calcola e visualizza la differenza tra i fileset
export async function calculateAndVisualizeDifference(selectedVariable, levelSliceConfig, sectionXSliceConfig, sectionYSliceConfig, viewType = 'all') {
    const filesetA = state.filesetA;
    const filesetB = state.filesetB;
    const selectedPath = DOM.selectDataGroup.value;

    const filesA = getFilesInFolder(filesetA.structure, selectedPath);
    const filesB = getFilesInFolder(filesetB.structure, selectedPath);
    const fileSeriesA = getFileCoupleSeries(filesA);
    const fileSeriesB = getFileCoupleSeries(filesB);

    if (fileSeriesA.length > 0 && fileSeriesB.length > 0) {
        const currentTimeIndex = parseInt(DOM.timeSlider.value);
        const edtFileA = fileSeriesA[currentTimeIndex].EDT;
        const edtFileB = fileSeriesB[currentTimeIndex].EDT;
        const edxInfoA = await readEDXFile(fileSeriesA[currentTimeIndex].EDX);
        const edxInfoB = await readEDXFile(fileSeriesB[currentTimeIndex].EDX);

        if (edtFileA && edtFileB && edxInfoA && edxInfoB) {
            if (viewType === 'all' || viewType === 'level') {
                const levelSliceDataA = await readEDTFile(edtFileA, edxInfoA, selectedVariable, { ...levelSliceConfig, terrainData: state.terrainDataA });
                const levelSliceDataB = await readEDTFile(edtFileB, edxInfoB, selectedVariable, { ...levelSliceConfig, terrainData: state.terrainDataB });
                const levelDiffData = calculateDifference(levelSliceDataA, levelSliceDataB);
                visualizeData(levelDiffData, state.dimensions, levelSliceConfig, selectedVariable, 'level', 'filesetDiff', state.differenceOrder);
            }

            if (viewType === 'all' || viewType === 'section-x') {
                const sectionXSliceDataA = await readEDTFile(edtFileA, edxInfoA, selectedVariable, sectionXSliceConfig);
                const sectionXSliceDataB = await readEDTFile(edtFileB, edxInfoB, selectedVariable, sectionXSliceConfig);
                const sectionXDiffData = calculateDifference(sectionXSliceDataA, sectionXSliceDataB);
                visualizeData(sectionXDiffData, state.dimensions, sectionXSliceConfig, selectedVariable, 'section-x', 'filesetDiff', state.differenceOrder);
            }

            if (viewType === 'all' || viewType === 'section-y') {
                const sectionYSliceDataA = await readEDTFile(edtFileA, edxInfoA, selectedVariable, sectionYSliceConfig);
                const sectionYSliceDataB = await readEDTFile(edtFileB, edxInfoB, selectedVariable, sectionYSliceConfig);
                const sectionYDiffData = calculateDifference(sectionYSliceDataA, sectionYSliceDataB);
                visualizeData(sectionYDiffData, state.dimensions, sectionYSliceConfig, selectedVariable, 'section-y', 'filesetDiff', state.differenceOrder);
            }
        }
    }
}

// Calcola la differenza tra i dati di due fileset
export function calculateDifference(dataA, dataB) {
    const length = Math.min(dataA.length, dataB.length);
    const isAMinusB = state.differenceOrder === 'A-B';

    // Creiamo un nuovo array ogni volta invece di riutilizzare this.resultArray
    const resultArray = new Float32Array(length);

    for (let i = 0; i < length; i++) {
        const valueA = dataA[i];
        const valueB = dataB[i];
        resultArray[i] = (valueA === null || valueB === null) ? null :
            (isAMinusB ? valueA - valueB : valueB - valueA);
    }

    return resultArray;
}

// Calcola la differenza tra i dati di due fileset

export function incrementTime() {
    if (!DOM.timeSlider) {
        //console.error("Elemento timeSlider non trovato!");
        return;
    }
    changeSliderValue(DOM.timeSlider, true);
    handleTimeSliderChange();
}

export function decrementTime() {
    if (!DOM.timeSlider) {
        //console.error("Elemento timeSlider non trovato!");
        return;
    }
    changeSliderValue(DOM.timeSlider, false);
    handleTimeSliderChange();
}

async function readAllEDTFiles(filesetKey, selectedPath, selectedVariable) {
    const fileset = state[filesetKey];
    if (!fileset) return [];

    const files = getFilesInFolder(fileset.structure, selectedPath);
    const fileSeries = getFileCoupleSeries(files);
    const data = [];

    for (const filePair of fileSeries) {
        const edtFile = filePair.EDT;
        const edxFile = filePair.EDX;
        const edxInfo = await readEDXFile(edxFile);
        
        const level = parseInt(DOM.levelSlider.value);
        const sectionX = parseInt(DOM.sectionXSlider.value);
        const sectionY = parseInt(DOM.sectionYSlider.value);

        const sliceConfig = {
            level,
            sectionX,
            sectionY,
            terrainData: state[`terrainData${filesetKey.slice(-1)}`],
            spacing: state.spacing
        };

        const sliceData = await readEDTFile(edtFile, edxInfo, selectedVariable, sliceConfig);
        const value = sliceData[sectionY * state.dimensions.x + sectionX];
        
        // Estrai la data dal nome del file
        const dateMatch = edtFile.name.match(/(\d{4}-\d{2}-\d{2})(?:_(\d{2}\.\d{2}\.\d{2}))?/);
        const date = dateMatch ? dateMatch[1] : '';
        const time = dateMatch && dateMatch[2] ? dateMatch[2].replace(/\./g, ':') : '00:00:00';
        
        data.push({
            date: `${date}T${time}`,
            value: value !== null ? value : null
        });
    }

    return data;
}

function prepareTimeSeriesData(dataA, dataB) {
    const mergedData = dataA.map((item, index) => ({
        date: item.date,
        valueA: item.value,
        valueB: dataB[index] ? dataB[index].value : null
    }));

    return mergedData.sort((a, b) => new Date(a.date) - new Date(b.date));
}
