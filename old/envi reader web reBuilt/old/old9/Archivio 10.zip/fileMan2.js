import { processEDXFile } from './processing.js';
import { COLOR_PALETTES } from './options.js';
import { FILE_STRUCTURE } from './options.js';
import { DOM } from './enviropment.js';
import { state } from './enviropment.js';
import { readEDXFile } from './processing.js';
import { calculateMetersValue } from './utils.js';
import { handleDirectorySelection } from './utils.js';
import { updateVisualization } from './viz.js';
import { handleResize } from './events.js';
import { findEDXFile } from './fileMan.js';
import { updateTimeSlider } from './fileMan.js';
import { getFilesInFolder } from './fileMan.js';
import { getFileCoupleSeries } from './fileMan.js';
import { updateSliderLabel } from './fileMan.js';
import { updateTimeLabel } from './fileMan.js';


// Gestione del cambio dello schema di colori
export let selectedPalette = ['#2b82b8', '#2ab1d5', '#59cee5', '#abe7f2', '#ccf0f7']; // Default palette


export let selectedPath = ""



// Funzione per aggiornare il fileset selezionato
export async function updateFileset(filesetKey) {
    const result = await handleDirectorySelection();
    
    if (!result) {

        //console.log(`${filesetKey} non selezionato`);
        return;
    }

    state[filesetKey] = result;
    //console.log(`Updated state for ${filesetKey}:`, state[filesetKey]);
    updatePathDisplays();
    //console.log(`${filesetKey} directory structure:`, result.structure);

    const edxFile = findEDXFile(result.structure);
    if (!edxFile) {
        //console.warn(`Nessun file EDX trovato per ${filesetKey}`);
        return;
    }

    try {
        const edxInfo = await processEDXFile(edxFile, filesetKey);
        state.edxVariables = edxInfo.variableNames;

        const selectedPath = DOM.selectDataGroup.value;
        await updateDataMenu(selectedPath);
    } catch (error) {
        //console.error(`Errore nel processare il file EDX per ${filesetKey}:`, error);
    }

    await updateTimeSlider();
    updateSliderRanges();
}

// Aggiorna il display del percorso per il fileset
export function updatePathDisplay(filesetKey) {
    const { rootDir } = state[filesetKey];
    const selectedPath = DOM.selectDataGroup.value;
    const fullPath = `${rootDir}/${selectedPath}`;
    DOM[`pathDisplay${filesetKey.slice(-1)}`].textContent = `Selected path: ${fullPath}`;
}


// Popola il menu a tendina del gruppo dati
export function populateDataGroupDropdown(structure = FILE_STRUCTURE, prefix = '') {
    if (!DOM.selectDataGroup) {
        //console.error("Elemento select per il gruppo di dati non trovato!");
        return;
    }

    Object.entries(structure).forEach(([key, value]) => {
        const fullPath = prefix ? `${prefix}/${key}` : key;

        const option = document.createElement('option');
        option.value = option.textContent = fullPath;
        DOM.selectDataGroup.appendChild(option);

        if (value && typeof value === 'object' && !Array.isArray(value)) {
            populateDataGroupDropdown(value, fullPath);
        }
    });
}
// Popola il menu a tendina delle variabili
export function populateVariableDropdown(variableNames) {
    const selectElement = DOM.selectData;
    if (!selectElement) {
        //console.error(`Elemento select per i dati non trovato!`);
        return;
    }

    const fragment = document.createDocumentFragment();
    variableNames.forEach(name => {
        const option = document.createElement('option');
        option.value = option.textContent = name;
        fragment.appendChild(option);
    });

    selectElement.innerHTML = '';
    selectElement.appendChild(fragment);

    //console.log(`Menu a tendina 'Data' aggiornato con nuove variabili.`);
}

// Aggiorna il menu dei dati
export async function updateDataMenu(selectedPath) {
    if (!DOM.selectData) {
        //console.error("Elemento select per i dati non trovato!");
        return;
    }

    const { filesetA, filesetB } = state;

    let files = [];
    if (filesetA) files = files.concat(getFilesInFolder(filesetA.structure, selectedPath));
    if (filesetB) files = files.concat(getFilesInFolder(filesetB.structure, selectedPath));

    const fileSeries = getFileCoupleSeries(files);
    if (fileSeries.length > 0) {
        const edxFile = fileSeries[0].EDX;
        try {
            const edxInfo = await readEDXFile(edxFile);
            populateVariableDropdown(edxInfo.variableNames);
        } catch (error) {
            //console.error(`Errore nella lettura del file EDX: ${error}`);
            DOM.selectData.innerHTML = '<option value="">Errore nella lettura dei dati</option>';
        }
    } else {
        //console.warn(`Nessuna coppia di file EDT/EDX valida trovata per il percorso selezionato: ${selectedPath}`);
        DOM.selectData.innerHTML = '<option value="">Nessun dato disponibile</option>';
    }
}
// Aggiorna i range degli slider
export function updateSliderRanges() {
    if (!state.dimensions) {
        //console.error("Le dimensioni dei dati non sono disponibili");
        return;
    }

    const { x: nrXData, y: nrYData, z: nrZData } = state.dimensions;

    // Aggiorna il range dello slider Level
    DOM.levelSlider.min = 0;
    DOM.levelSlider.max = nrZData - 1;
    DOM.levelSlider.value = 0;

    // Aggiorna il range dello slider Section X
    DOM.sectionXSlider.min = 0;
    DOM.sectionXSlider.max = nrXData - 1;
    DOM.sectionXSlider.value = Math.min(DOM.sectionXSlider.value, nrXData - 1);

    // Aggiorna il range dello slider Section Y
    DOM.sectionYSlider.min = 0;
    DOM.sectionYSlider.max = nrYData - 1;
    DOM.sectionYSlider.value = Math.min(DOM.sectionYSlider.value, nrYData - 1);

    // Aggiorna le etichette degli slider
    updateLevelLabel();
    updateSectionXLabel();
    updateSectionYLabel();
}

// Aggiorna l'etichetta del livello
export function updateLevelLabel() {
    updateSliderLabel('levelSlider', 'levelLabel', (value) => {
        const metersValue = calculateMetersValue(value, state.spacing?.z || []);
        return `${value} (${metersValue.toFixed(2)}m)`;
    });
}

// Aggiorna l'etichetta della sezione X
export function updateSectionXLabel() {
    updateSliderLabel('sectionXSlider', 'sectionXLabel', (value) => {
        const metersValue = calculateMetersValue(value, state.spacing?.x || []);
        return `${value} (${metersValue.toFixed(2)}m)`;
    });
}
// Aggiorna l'etichetta della sezione Y
export function updateSectionYLabel() {
    updateSliderLabel('sectionYSlider', 'sectionYLabel', (value) => {
        const metersValue = calculateMetersValue(value, state.spacing?.y || []);
        return `${value} (${metersValue.toFixed(2)}m)`;
    });
}
// Aggiorna l'etichetta dell'opacitÃ  del vento
export function updateWindOpacityLabel() {
    updateSliderLabel('windOpacitySlider', 'windOpacityLabel', (value) => `${value}%`);
}

// Aggiorna l'etichetta dell'animazione del vento
export function updateWindAnimationLabel() {
    updateSliderLabel('windAnimationSlider', 'windAnimationLabel', (value) => `${value}%`);
}

// Aggiorna l'etichetta della densitÃ  del vento
export function updateWindDensityLabel() {
    updateSliderLabel('windDensitySlider', 'windDensityLabel', (value) => `${value}%`);
}
export function updateAllLabels() {
    updateTimeLabel();
    updateLevelLabel();
    updateSectionXLabel();
    updateSectionYLabel();
    updateWindOpacityLabel();
    updateWindAnimationLabel();
    updateWindDensityLabel();
}
// Aggiorna la rotazione del bottone del toggle
export function updateButtonRotation() {
    const container = document.querySelector('.container');
    const toggleButton = document.getElementById('toggle-sidebar');
    const toggleIcon = toggleButton.querySelector('.material-icons');
    const isMobile = window.innerWidth <= 768;
    const isSidebarVisible = !container.classList.contains('sidebar-hidden');

    if (isMobile) {
        if (isSidebarVisible) {
            toggleIcon.style.transform = 'rotate(90deg)';
        } else {
            toggleIcon.style.transform = 'rotate(-90deg)';
        }
    } else {
        toggleIcon.style.transform = isSidebarVisible ? 'rotate(0deg)' : 'rotate(180deg)';
    }
}

export function createPathDisplay() {
    // Crea e aggiunge i display dei percorsi
    DOM.pathDisplayA.className = 'path-display';
    DOM.pathDisplayB.className = 'path-display';
    DOM.buttonFilesetA.insertAdjacentElement('afterend', DOM.pathDisplayA);
    DOM.buttonFilesetB.insertAdjacentElement('afterend', DOM.pathDisplayB);
}

export function initializeColorPaletteSelector() {
    const selectedPalette = document.querySelector('.selected-palette');
    const paletteOptions = document.querySelector('.palette-options');

    if (!selectedPalette || !paletteOptions) {
        //console.error("Elementi del selettore della palette di colori non trovati!");
        return;
    }

    selectedPalette.addEventListener('click', () => {
        paletteOptions.classList.toggle('show');
    });

    // Chiudi il selettore quando si clicca fuori
    document.addEventListener('click', (event) => {
        if (!event.target.closest('.color-palette-selector')) {
            paletteOptions.classList.remove('show');
        }
    });

    populateColorPaletteSelector();
}

export function populateColorPaletteSelector() {
    const paletteSelector = document.querySelector('.color-palette-selector');
    const paletteOptions = paletteSelector.querySelector('.palette-options');

    if (!paletteSelector || !paletteOptions) {
        //console.error("Elementi del selettore della palette di colori non trovati!");
        return;
    }

    for (const category in COLOR_PALETTES) {
        for (const paletteNumber in COLOR_PALETTES[category]) {
            const palette = COLOR_PALETTES[category][paletteNumber];
            const option = document.createElement('div');
            option.classList.add('palette-option');
            option.setAttribute('data-value', `${category}|${paletteNumber}`);

            const preview = document.createElement('div');
            preview.classList.add('palette-preview');
            palette.forEach(color => {
                const colorSample = document.createElement('div');
                colorSample.classList.add('color-sample');
                colorSample.style.backgroundColor = color;
                preview.appendChild(colorSample);
            });

            const name = document.createElement('span');
            name.classList.add('palette-name');
            name.textContent = `${category} - Palette ${paletteNumber}`;

            option.appendChild(preview);
            option.appendChild(name);
            paletteOptions.appendChild(option);
        }
    }

    // Aggiungi l'event listener per la selezione della palette
    paletteOptions.addEventListener('click', handlePaletteSelection);
}

export function handlePaletteSelection(event) {
    const option = event.target.closest('.palette-option');
    if (!option) return;

    const value = option.getAttribute('data-value');
    const [category, paletteNumber] = value.split('|');
    selectedPalette = COLOR_PALETTES[category][paletteNumber];

    const selectedPaletteName = document.querySelector('.selected-palette-name');
    if (selectedPaletteName) {
        selectedPaletteName.textContent = `${category} - Palette ${paletteNumber}`;
    }

    document.querySelector('.palette-options').classList.remove('show');

    //console.log("Color palette changed:", selectedPalette);
    updateVisualization('filesetA');
    updateVisualization('filesetB');
}

// Inizializza il toggle della sidebar
export function initSidebarToggle() {
    const toggleButton = document.getElementById('toggle-sidebar');
    const container = document.querySelector('.container');



    toggleButton.addEventListener('click', () => {
        container.classList.toggle('sidebar-hidden');
        container.classList.toggle('sidebar-visible');
        updateButtonRotation();

        handleResize();

        setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
        }, 300);
    });
}

// Inizializza il menu dei dati
export async function initializeDataMenu() {
    if (!DOM.selectDataGroup || !DOM.selectData) {
        //console.error("Elementi select necessari non trovati!");
        return;
    }

    const selectedPath = DOM.selectDataGroup.value;
    await updateDataMenu(selectedPath);
    state.filesetA = null;
    state.filesetB = null;
}


export function handleColorSchemeChange() {
    const [category, paletteNumber] = DOM.colorPaletteSelector.value.split('|');
    selectedPalette = COLOR_PALETTES[category][paletteNumber];
    //console.log("Color palette changed:", selectedPalette);
    updateVisualization('filesetA');
    updateVisualization('filesetB');
}

// Aggiorna i display dei percorsi per tutti i fileset
export function updatePathDisplays() {
    selectedPath = DOM.selectDataGroup.value;
    ['filesetA', 'filesetB'].forEach(filesetKey => {
        const fileset = state[filesetKey];
        if (fileset) {
            updatePathDisplay(filesetKey);
        }
    });
}
