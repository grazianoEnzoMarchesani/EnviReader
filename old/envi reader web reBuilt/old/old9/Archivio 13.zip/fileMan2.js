import { COLOR_PALETTES } from './options.js';
import { DOM } from './enviropment.js';
import { state } from './enviropment.js';
import { updateVisualization } from './viz.js';
import { handleResize } from './events.js';
updatePatDisplay
import { updatePathDisplay } from './fileMan.js';


// Gestione del cambio dello schema di colori
export let selectedPalette = ['#2b82b8', '#2ab1d5', '#59cee5', '#abe7f2', '#ccf0f7']; // Default palette


export let selectedPath = ""


export function populateColorPaletteSelector() {
    const paletteSelector = document.querySelector('.color-palette-selector');
    const paletteOptions = paletteSelector.querySelector('.palette-options');

    if (!paletteSelector || !paletteOptions) {
        //console.error("Elementi del selettore della palette di colori non trovati!");
        return;
    }

    for (const category in COLOR_PALETTES) {
        for (const paletteNumber in COLOR_PALETTES[category]) {
            const palette = COLOR_PALETTES[category][paletteNumber];
            const option = document.createElement('div');
            option.classList.add('palette-option');
            option.setAttribute('data-value', `${category}|${paletteNumber}`);

            const preview = document.createElement('div');
            preview.classList.add('palette-preview');
            palette.forEach(color => {
                const colorSample = document.createElement('div');
                colorSample.classList.add('color-sample');
                colorSample.style.backgroundColor = color;
                preview.appendChild(colorSample);
            });

            const name = document.createElement('span');
            name.classList.add('palette-name');
            name.textContent = `${category} - Palette ${paletteNumber}`;

            option.appendChild(preview);
            option.appendChild(name);
            paletteOptions.appendChild(option);
        }
    }

    // Aggiungi l'event listener per la selezione della palette
    paletteOptions.addEventListener('click', handlePaletteSelection);
}

export function handlePaletteSelection(event) {
    const option = event.target.closest('.palette-option');
    if (!option) return;

    const value = option.getAttribute('data-value');
    const [category, paletteNumber] = value.split('|');
    selectedPalette = COLOR_PALETTES[category][paletteNumber];

    const selectedPaletteName = document.querySelector('.selected-palette-name');
    if (selectedPaletteName) {
        selectedPaletteName.textContent = `${category} - Palette ${paletteNumber}`;
    }

    document.querySelector('.palette-options').classList.remove('show');

    //console.log("Color palette changed:", selectedPalette);
    updateVisualization('filesetA');
    updateVisualization('filesetB');
}

// Inizializza il toggle della sidebar
export function initSidebarToggle() {
    const toggleButton = document.getElementById('toggle-sidebar');
    const container = document.querySelector('.container');



    toggleButton.addEventListener('click', () => {
        container.classList.toggle('sidebar-hidden');
        container.classList.toggle('sidebar-visible');
      

        handleResize();

        setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
        }, 300);
    });
}

// Inizializza il menu dei dati
export async function initializeDataMenu() {
    if (!DOM.selectDataGroup || !DOM.selectData) {
        //console.error("Elementi select necessari non trovati!");
        return;
    }

    const selectedPath = DOM.selectDataGroup.value;
    await updateDataMenu(selectedPath);
    state.filesetA = null;
    state.filesetB = null;
}


export function handleColorSchemeChange() {
    const [category, paletteNumber] = DOM.colorPaletteSelector.value.split('|');
    selectedPalette = COLOR_PALETTES[category][paletteNumber];
    //console.log("Color palette changed:", selectedPalette);
    updateVisualization('filesetA');
    updateVisualization('filesetB');
}

// Aggiorna i display dei percorsi per tutti i fileset
export function updatePathDisplays() {
    selectedPath = DOM.selectDataGroup.value;
    ['filesetA', 'filesetB'].forEach(filesetKey => {
        const fileset = state[filesetKey];
        if (fileset) {
            updatePathDisplay(filesetKey);
        }
    });
}
