
//....enviropment.js
import { DOM } from './enviropment.js';

//....updateUi.js
import { updateChartsTextColor } from './fileMan.js';

import { updateTimeSlider } from './fileMan.js';
import { updateLegendScale } from './fileMan.js';

import { updateSliderRanges } from './fileMan.js';


import { populateDataGroupDropdown } from './fileMan.js';
import { updateAllLabels } from './fileMan.js';
import { createPathDisplay } from './fileMan.js';
import { initResizeListener } from './utils.js';
import { initializeColorPaletteSelector } from './fileMan.js';
import { initSidebarToggle } from './fileMan.js';
import { initializeDataMenu } from './fileMan.js';
import { initializeTextScaling } from './fileMan.js';


//....utils.js
import { debounce } from './utils.js';

import { initializeDOMReferences } from './utils.js';
import { resizeAllCharts } from './utils.js';

//....events.js
import { handleResize } from './events.js';
import { addEventListeners } from './events.js';

//....viz.js
import { updateVisualization } from './viz.js';
import { cleanupCharts } from './viz.js';
import { debugChartUpdates } from './viz.js';


import { saveAllCharts } from './imageExport.js';



debounce(updateVisualization, 250);


function addSaveAllChartsListener() {
    const saveAllChartsButton = document.getElementById('saveAllChartsButton');
    if (saveAllChartsButton) {
        saveAllChartsButton.addEventListener('click', saveAllCharts);
    } else {
        console.error("Elemento 'saveAllChartsButton' non trovato!");
    }
}


// Funzione di inizializzazione
async function init() {
    initResizeListener();
    debugChartUpdates();

    addSaveAllChartsListener();


    const cleanup = () => {
        window.removeEventListener('resize', handleResize);
        cleanupCharts();
    };
    window.addEventListener('beforeunload', cleanup);

    initializeDOMReferences();
    createPathDisplay();
    initializeColorPaletteSelector();

    if (DOM.selectDataGroup) {
        await populateDataGroupDropdown();
        DOM.selectDataGroup.value = DOM.selectDataGroup.options[0].value;
    } else {
        console.error("Elemento select per il gruppo di dati non trovato durante l'inizializzazione!");
    }

    addEventListeners();
    initSidebarToggle();
    handleResize();

    window.addEventListener('resize', handleResize);

    const container = document.querySelector('.container');
    if (!container.classList.contains('sidebar-hidden')) {
        container.classList.add('sidebar-visible');
    }

    // Lazy load delle funzionalità non essenziali
    setTimeout(() => {
        updateSliderRanges();
        updateAllLabels();
        if (DOM.timeSlider && DOM.selectDataGroup) {
            updateTimeSlider();
        }
        initializeDataMenu();
        resizeAllCharts();
        updateLegendScale();
    }, 0);
    
}




// Event listener per il caricamento del DOM
document.addEventListener('DOMContentLoaded', init);

// Gestione del tema scuro/chiaro
document.addEventListener('DOMContentLoaded', () => {

    initializeTextScaling();
    const themeSwitcher = document.getElementById('theme-icon');

    const currentTheme = localStorage.getItem('theme') || 'light';
    document.body.classList.add(`${currentTheme}-mode`);
    themeSwitcher.classList.add(currentTheme === 'light' ? 'icon-sun' : 'icon-moon');

    themeSwitcher.addEventListener('click', () => {
        const isLight = document.body.classList.contains('light-mode');
        document.body.classList.toggle('light-mode', !isLight);
        document.body.classList.toggle('dark-mode', isLight);
        themeSwitcher.classList.toggle('icon-sun', !isLight);
        themeSwitcher.classList.toggle('icon-moon', isLight);

        localStorage.setItem('theme', isLight ? 'dark' : 'light');
        updateChartsTextColor();
    });
});