import { state } from './enviropment.js';
import { chartInstances } from './enviropment.js';
import { calculateMetersValue } from './utils.js';

export function captureChartImage(chartKey) {
    return new Promise((resolve, reject) => {
        const chart = chartInstances[chartKey];
        if (!chart) {
            reject(new Error(`Chart non trovato per la chiave ${chartKey}`));
            return;
        }

        const container = chart.getDom().closest('.chart-container');
        if (!container) {
            reject(new Error('Container del chart non trovato'));
            return;
        }

        const svgContent = chart.renderToSVGString({
            pixelRatio: 2,
            excludeComponents: ['toolbox']
        });

        const chartInfo = extractChartInfo(container, chartKey);
        const svgWithInfo = addInfoToSVG(svgContent, chartInfo);

        resolve(svgWithInfo);
    });
}

function extractChartInfo(container, chartKey) {
    const titleElement = container.querySelector('h3');
    const subtitleElement = container.querySelector('.chart-subtitle');
    const infoDiv = container.querySelector('.info-div');

    const title = titleElement ? titleElement.textContent : '';
    const subtitle = subtitleElement ? subtitleElement.textContent : '';
    const info = infoDiv ? infoDiv.textContent : '';

    // Estrai informazioni aggiuntive dallo stato
    const [filesetKey, viewType] = chartKey.split('-');
    const { dimensions, spacing } = state;
    let additionalInfo = '';

    if (viewType === 'level') {
        const level = parseInt(document.getElementById('levelSlider').value);
        additionalInfo = `Level: ${level} (${calculateMetersValue(level, spacing.z).toFixed(2)}m)`;
    } else if (viewType === 'section-x') {
        const sectionX = parseInt(document.getElementById('sectionXSlider').value);
        additionalInfo = `X: ${sectionX} (${calculateMetersValue(sectionX, spacing.x).toFixed(2)}m)`;
    } else if (viewType === 'section-y') {
        const sectionY = parseInt(document.getElementById('sectionYSlider').value);
        additionalInfo = `Y: ${sectionY} (${calculateMetersValue(sectionY, spacing.y).toFixed(2)}m)`;
    }

    return { title, subtitle, info, additionalInfo };
}

function addInfoToSVG(svgContent, chartInfo) {
    const parser = new DOMParser();
    const svgDoc = parser.parseFromString(svgContent, 'image/svg+xml');
    const svg = svgDoc.documentElement;

    // Ottieni le dimensioni attuali dell'SVG
    let width = parseInt(svg.getAttribute('width'));
    let height = parseInt(svg.getAttribute('height'));

    // Aumenta l'altezza dell'SVG di 150px
    height += 150;
    svg.setAttribute('height', height);

    // Crea un gruppo per il contenuto originale e spostalo verso il basso
    const contentGroup = svgDoc.createElementNS('http://www.w3.org/2000/svg', 'g');
    contentGroup.setAttribute('transform', 'translate(0, 150)');

    // Sposta tutti gli elementi figlio dell'SVG nel nuovo gruppo
    while (svg.firstChild) {
        contentGroup.appendChild(svg.firstChild);
    }

    // Aggiungi il gruppo del contenuto all'SVG
    svg.appendChild(contentGroup);

    // Crea un gruppo per il testo
    const textGroup = svgDoc.createElementNS('http://www.w3.org/2000/svg', 'g');
    textGroup.setAttribute('font-family', 'Helvetica, Arial, sans-serif');
    textGroup.setAttribute('font-size', '14');
    textGroup.setAttribute('fill', 'black');  // Impostiamo il colore nero per tutti i testi

    // Aggiungi titolo
    const titleText = svgDoc.createElementNS('http://www.w3.org/2000/svg', 'text');
    titleText.setAttribute('x', '10');
    titleText.setAttribute('y', '30');
    titleText.setAttribute('font-weight', 'bold');
    titleText.textContent = chartInfo.title;
    textGroup.appendChild(titleText);

    // Aggiungi sottotitolo
    const subtitleText = svgDoc.createElementNS('http://www.w3.org/2000/svg', 'text');
    subtitleText.setAttribute('x', '10');
    subtitleText.setAttribute('y', '55');
    subtitleText.setAttribute('font-size', '12');
    subtitleText.textContent = chartInfo.subtitle;
    textGroup.appendChild(subtitleText);

    // Aggiungi info
    const infoText = svgDoc.createElementNS('http://www.w3.org/2000/svg', 'text');
    infoText.setAttribute('x', '10');
    infoText.setAttribute('y', '80');
    infoText.setAttribute('font-size', '12');
    infoText.setAttribute('font-style', 'italic');
    infoText.textContent = chartInfo.info;
    textGroup.appendChild(infoText);

    // Aggiungi info aggiuntive
    const additionalInfoText = svgDoc.createElementNS('http://www.w3.org/2000/svg', 'text');
    additionalInfoText.setAttribute('x', '10');
    additionalInfoText.setAttribute('y', '105');
    additionalInfoText.setAttribute('font-size', '12');
    additionalInfoText.textContent = chartInfo.additionalInfo;
    textGroup.appendChild(additionalInfoText);

    // Inserisci il gruppo di testo all'inizio dell'SVG
    svg.insertBefore(textGroup, svg.firstChild);

    // Colora di nero tutti i testi esistenti nell'SVG
    setAllTextColorToBlack(svg);

    // Converti l'SVG modificato in stringa
    const serializer = new XMLSerializer();
    return serializer.serializeToString(svgDoc);
}

function setAllTextColorToBlack(element) {
    // Se l'elemento è un nodo di testo, imposta il colore a nero
    if (element.tagName === 'text' || element.tagName === 'tspan') {
        element.setAttribute('fill', 'black');
    }

    // Se l'elemento ha figli, applica ricorsivamente la funzione
    if (element.children) {
        Array.from(element.children).forEach(setAllTextColorToBlack);
    }
}


export function saveSingleChart(chartKey) {
    const chart = chartInstances[chartKey];
    if (!chart) {
        console.error(`Chart non trovato per la chiave ${chartKey}`);
        return;
    }

    try {
        captureChartImage(chartKey).then(svgContent => {
            // Crea un Blob con il contenuto SVG
            const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });

            // Crea un URL per il blob
            const url = URL.createObjectURL(blob);

            // Crea un link per il download e fai clic su di esso
            const link = document.createElement('a');
            link.href = url;
            link.download = `chart_${chartKey}.svg`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            // Rilascia l'URL del blob
            URL.revokeObjectURL(url);

            console.log(`Chart ${chartKey} saved successfully as SVG`);
        }).catch(error => {
            console.error(`Errore nel salvataggio del grafico ${chartKey}:`, error);
            alert(`Si è verificato un errore durante il salvataggio del grafico ${chartKey}. Per favore, riprova.`);
        });
    } catch (error) {
        console.error(`Errore durante la preparazione del salvataggio per il grafico ${chartKey}:`, error);
        alert(`Si è verificato un errore imprevisto durante la preparazione del salvataggio per il grafico ${chartKey}. Per favore, riprova.`);
    }
}



export function saveAllCharts() {
    Object.keys(chartInstances).forEach((chartKey, index) => {
        setTimeout(() => {
            saveSingleChart(chartKey);
        }, index * 500);
    });
}