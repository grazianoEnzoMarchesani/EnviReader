
//import globals from "globals";
//import pluginJs from "@eslint/js";


//export default [
//  {files: ["**/*.js"], languageOptions: {sourceType: "commonjs"}},
//  {languageOptions: { globals: globals.browser }},
//  pluginJs.configs.recommended,
//];


import globals from "globals";
import pluginJs from "@eslint/js";

export default [
  {
    // Specifica che tutti i file con estensione .js devono essere trattati come moduli ES6
    files: ["**/*.js"],
    languageOptions: {
      sourceType: "module",  // Modifica il sourceType da "commonjs" a "module"
    },
  },
  {
    languageOptions: {
      globals: globals.browser,
    },
  },
  pluginJs.configs.recommended,
];

