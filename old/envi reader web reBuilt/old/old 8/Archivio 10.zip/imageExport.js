import { state } from './enviropment.js';
import { chartInstances } from './enviropment.js';
import { calculateMetersValue } from './utils.js';

export function captureChartImage(chartKey) {
    return new Promise((resolve, reject) => {
        const chart = chartInstances[chartKey];
        if (!chart) {
            reject(new Error(`Chart non trovato per la chiave ${chartKey}`));
            return;
        }

        const container = chart.getDom().closest('.chart-container');
        if (!container) {
            reject(new Error('Container del chart non trovato'));
            return;
        }

        const svgContent = chart.renderToSVGString({
            pixelRatio: 2,
            excludeComponents: ['toolbox']
        });

        const chartInfo = extractChartInfo(container, chartKey);
        const svgWithInfo = addInfoToSVG(svgContent, chartInfo);

        resolve(svgWithInfo);
    });
}

function extractChartInfo(container, chartKey) {
    const titleElement = container.querySelector('h3');
    const subtitleElement = container.querySelector('.chart-subtitle');
    const infoDiv = container.querySelector('.info-div');

    const title = titleElement ? titleElement.textContent : '';
    const subtitle = subtitleElement ? subtitleElement.textContent : '';
    const info = infoDiv ? infoDiv.textContent : '';

    // Estrai informazioni aggiuntive dallo stato
    const [filesetKey, viewType] = chartKey.split('-');
    const { dimensions, spacing } = state;
    let additionalInfo = '';

    if (viewType === 'level') {
        const level = parseInt(document.getElementById('levelSlider').value);
        additionalInfo = `Level: ${level} (${calculateMetersValue(level, spacing.z).toFixed(2)}m)`;
    } else if (viewType === 'section-x') {
        const sectionX = parseInt(document.getElementById('sectionXSlider').value);
        additionalInfo = `X: ${sectionX} (${calculateMetersValue(sectionX, spacing.x).toFixed(2)}m)`;
    } else if (viewType === 'section-y') {
        const sectionY = parseInt(document.getElementById('sectionYSlider').value);
        additionalInfo = `Y: ${sectionY} (${calculateMetersValue(sectionY, spacing.y).toFixed(2)}m)`;
    }

    return { title, subtitle, info, additionalInfo };
}

function addInfoToSVG(svgContent, chartInfo) {
    const parser = new DOMParser();
    const svgDoc = parser.parseFromString(svgContent, 'image/svg+xml');
    const svg = svgDoc.documentElement;

    // Ottieni le dimensioni originali
    const originalWidth = parseInt(svg.getAttribute('width') || svg.width.baseVal.value);
    const originalHeight = parseInt(svg.getAttribute('height') || svg.height.baseVal.value);

    // Calcola le nuove dimensioni mantenendo l'aspect ratio
    const maxWidth = 800; // Imposta una larghezza massima desiderata
    const scaleFactor = Math.min(1, maxWidth / originalWidth);
    const newWidth = Math.round(originalWidth * scaleFactor);
    const newHeight = Math.round(originalHeight * scaleFactor);

    // Aggiungi spazio per il testo informativo
    const infoHeight = 150;
    const totalHeight = newHeight + infoHeight;

    // Crea un gruppo per il contenuto originale
    const contentGroup = svgDoc.createElementNS('http://www.w3.org/2000/svg', 'g');
    
    // Sposta tutti gli elementi figlio dell'SVG nel nuovo gruppo
    while (svg.firstChild) {
        contentGroup.appendChild(svg.firstChild);
    }

    // Aggiungi il gruppo del contenuto all'SVG
    svg.appendChild(contentGroup);

    // Aggiorna le dimensioni dell'SVG
    svg.setAttribute('width', newWidth);
    svg.setAttribute('height', totalHeight);

    // Imposta il viewBox per includere tutto il contenuto
    svg.setAttribute('viewBox', `0 0 ${originalWidth} ${originalHeight + infoHeight / scaleFactor}`);

    // Scala e sposta il contenuto originale
    contentGroup.setAttribute('transform', `translate(0, ${infoHeight / scaleFactor}) scale(${scaleFactor})`);

    // Aggiungi il testo informativo
    addInfoText(svg, chartInfo, scaleFactor);

    // Colora di nero tutti i testi esistenti nell'SVG
    setAllTextColorToBlack(svg);

    // Converti l'SVG modificato in stringa
    const serializer = new XMLSerializer();
    return serializer.serializeToString(svgDoc);
}

function addInfoText(svg, chartInfo, scaleFactor) {
    const textGroup = svg.ownerDocument.createElementNS('http://www.w3.org/2000/svg', 'g');
    textGroup.setAttribute('font-family', 'Helvetica, Arial, sans-serif');
    textGroup.setAttribute('font-size', `${14 * scaleFactor}px`);
    textGroup.setAttribute('fill', 'black');

    const texts = [
        { text: chartInfo.title, x: 10, y: 30, weight: 'bold', size: 14 },
        { text: chartInfo.subtitle, x: 10, y: 55, size: 12 },
        { text: chartInfo.info, x: 10, y: 80, size: 12, style: 'italic' },
        { text: chartInfo.additionalInfo, x: 10, y: 105, size: 12 }
    ];

    texts.forEach(({ text, x, y, weight, size, style }) => {
        const textElement = svg.ownerDocument.createElementNS('http://www.w3.org/2000/svg', 'text');
        textElement.setAttribute('x', x);
        textElement.setAttribute('y', y);
        textElement.setAttribute('font-size', `${size * scaleFactor}px`);
        if (weight) textElement.setAttribute('font-weight', weight);
        if (style) textElement.setAttribute('font-style', style);
        textElement.textContent = text;
        textGroup.appendChild(textElement);
    });

    svg.insertBefore(textGroup, svg.firstChild);
}

function setAllTextColorToBlack(element) {
    // Se l'elemento è un nodo di testo, imposta il colore a nero
    if (element.tagName === 'text' || element.tagName === 'tspan') {
        element.setAttribute('fill', 'black');
    }

    // Se l'elemento ha figli, applica ricorsivamente la funzione
    if (element.children) {
        Array.from(element.children).forEach(setAllTextColorToBlack);
    }
}


export function saveSingleChart(chartKey) {
    const chart = chartInstances[chartKey];
    if (!chart) {
        console.error(`Chart non trovato per la chiave ${chartKey}`);
        return;
    }

    try {
        captureChartImage(chartKey).then(svgContent => {
            // Crea un Blob con il contenuto SVG
            const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });

            // Crea un URL per il blob
            const url = URL.createObjectURL(blob);

            // Crea un link per il download e fai clic su di esso
            const link = document.createElement('a');
            link.href = url;
            link.download = `chart_${chartKey}.svg`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            // Rilascia l'URL del blob
            URL.revokeObjectURL(url);

            console.log(`Chart ${chartKey} saved successfully as SVG`);
        }).catch(error => {
            console.error(`Errore nel salvataggio del grafico ${chartKey}:`, error);
            alert(`Si è verificato un errore durante il salvataggio del grafico ${chartKey}. Per favore, riprova.`);
        });
    } catch (error) {
        console.error(`Errore durante la preparazione del salvataggio per il grafico ${chartKey}:`, error);
        alert(`Si è verificato un errore imprevisto durante la preparazione del salvataggio per il grafico ${chartKey}. Per favore, riprova.`);
    }
}



export function saveAllCharts() {
    Object.keys(chartInstances).forEach((chartKey, index) => {
        setTimeout(() => {
            saveSingleChart(chartKey);
        }, index * 500);
    });
}