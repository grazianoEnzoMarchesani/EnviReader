
import { state } from './enviropment.js';
import { chartInstances } from './enviropment.js';



/************         Funzioni di visualizzazione         ************/


async function captureChartScreenshot(container, chartKey) {
    try {
        const canvas = await html2canvas(container, {
            scale: state.scaleFactor,
            logging: false,
            useCORS: true
        });
        return {
            name: `${chartKey}.png`,
            data: canvas.toDataURL('image/png')
        };
    } catch (error) {
        console.error(`Error capturing screenshot for ${chartKey}:`, error);
        return null;
    }
}

export async function captureAllChartScreenshots() {
    const screenshots = [];
    for (const [key, chart] of Object.entries(chartInstances)) {
        if (chart && chart.getDom()) {
            const container = chart.getDom().closest('.chart-container');
            if (container) {
                const screenshot = await captureChartScreenshot(container, key);
                if (screenshot) {
                    screenshots.push(screenshot);
                }
            }
        }
    }
    return screenshots;
}

export async function downloadChartsAsZip() {
    const screenshots = await captureAllChartScreenshots();
    if (screenshots.length === 0) {
        alert("No charts available to download.");
        return;
    }

    const zip = new JSZip();
    screenshots.forEach(screenshot => {
        zip.file(screenshot.name, screenshot.data.split('base64,')[1], {base64: true});
    });

    zip.generateAsync({type: 'blob'}).then(content => {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(content);
        link.download = 'charts_screenshots.zip';
        link.click();
        URL.revokeObjectURL(link.href);
    });
}