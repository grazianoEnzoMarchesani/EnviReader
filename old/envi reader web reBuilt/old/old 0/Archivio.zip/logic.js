// Struttura predefinita delle cartelle
const FILE_STRUCTURE = {
  ENVIObjects: {},
  atmosphere: {},
  biomet: {
    PET: {},
    PMV: {},
    SET: {},
    UTCI: {}
  },
  buildings: {
    BPS: {},
    dynamic: {},
    static: {}
  },
  inflow: {},
  inputData: {},
  log: {},
  radiation: {},
  receptors: {},
  soil: {},
  solaraccess: {
    facades: {},
    ground: {},
    points: {}
  },
  surface: {},
  vegetation: {
    dynamic: {},
    static: {}
  },
  windsectors: {}
};

const HIDDEN_DATA_GROUPS = ['ENVIObjects', 'biomet', 'buildings', 'buildings/dynamic', 'buildings/static', 'buildings/BPS', 'inputData', 'inflow', 'log', 'solaraccess', 'solaraccess/ground', 'solaraccess/facades', 'solaraccess/points', 'windsectors', 'vegetation/dynamic', 'vegetation/static'];

// Gestione dello stato dell'applicazione
const createState = () => ({
  filesetA: null,
  filesetB: null,
  currentTimeIndex: 0,
  isCongruent: true
});

const shouldHidePath = (path) => {
  return HIDDEN_DATA_GROUPS.some(hiddenPath => {
    const pathParts = path.split('/');
    const hiddenParts = hiddenPath.split('/');
    return pathParts.length === hiddenParts.length &&
      hiddenParts.every((part, index) => part === pathParts[index]);
  });
};

let state = createState();

// Selettori DOM
const DOM = {
  selectDataGroup: document.querySelector('select'),
  buttonFilesetA: document.querySelector('button:nth-of-type(1)'),
  buttonFilesetB: document.querySelector('button:nth-of-type(2)'),
  pathDisplayA: document.createElement('div'),
  pathDisplayB: document.createElement('div'),
  timeSlider: document.querySelector('input[type="range"]'),
  timeLabel: document.querySelector('.slider-title'),
  timeIncrementBtn: document.querySelector('.slider-btn[aria-label="Increment time"]'),
  timeDecrementBtn: document.querySelector('.slider-btn[aria-label="Decrement time"]')
};

// Funzioni di utilità

const createPathDisplay = () => {
  DOM.pathDisplayA.className = 'path-display';
  DOM.pathDisplayB.className = 'path-display';
  DOM.buttonFilesetA.insertAdjacentElement('afterend', DOM.pathDisplayA);
  DOM.buttonFilesetB.insertAdjacentElement('afterend', DOM.pathDisplayB);
};

const handleDirectorySelection = () => new Promise(resolve => {
  const input = document.createElement('input');
  input.type = 'file';
  input.webkitdirectory = input.directory = true;

  input.addEventListener('change', ({ target: { files } }) => {
    if (files.length === 0) return resolve(null);

    const directoryStructure = {};
    const rootDir = files[0].webkitRelativePath.split('/')[0];
    Array.from(files).forEach(file => {
      const parts = file.webkitRelativePath.split('/');
      let current = directoryStructure;
      for (let i = 1; i < parts.length; i++) {
        const part = parts[i];
        if (i === parts.length - 1) {
          if (!current.files) current.files = [];
          current.files.push(file);
        } else {
          if (!current[part]) current[part] = {};
          current = current[part];
        }
      }
    });
    resolve({ structure: directoryStructure, rootDir });
  });

  input.click();
});

const updateFileset = async (filesetKey) => {
  const result = await handleDirectorySelection();
  if (result) {
    state[filesetKey] = result;
    updatePathDisplays();
    console.log(`${filesetKey} directory structure:`, result.structure);

    // Trova il file EDX nella struttura della directory
    const edxFile = findEDXFile(result.structure);
    if (edxFile) {
      await processEDXFile(edxFile, filesetKey);
    } else {
      console.error(`Nessun file EDX trovato in ${filesetKey}`);
    }

    updateTimeSlider();
  } else {
    console.log(`${filesetKey} non selezionato`);
  }
};

const updatePathDisplay = (filesetKey) => {
  const { rootDir } = state[filesetKey];
  const selectedPath = DOM.selectDataGroup.value;
  const fullPath = `${rootDir}/${selectedPath}`;
  DOM[`pathDisplay${filesetKey.slice(-1)}`].textContent = `Selected path: ${fullPath}`;
};

const updatePathDisplays = () => {
  const selectedPath = DOM.selectDataGroup.value;
  ['filesetA', 'filesetB'].forEach(filesetKey => {
    const fileset = state[filesetKey];
    if (fileset) {
      const { rootDir } = fileset;
      const fullPath = `${rootDir}/${selectedPath}`;
      DOM[`pathDisplay${filesetKey.slice(-1)}`].textContent = `Selected path: ${fullPath}`;
    }
  });
};

const populateDataGroupDropdown = (structure = FILE_STRUCTURE, prefix = '') => {
  Object.entries(structure).forEach(([key, value]) => {
    const fullPath = prefix ? `${prefix}/${key}` : key;

    if (!shouldHidePath(fullPath)) {
      const option = document.createElement('option');
      option.value = option.textContent = fullPath;
      DOM.selectDataGroup.appendChild(option);
    }

    if (value && typeof value === 'object' && !Array.isArray(value)) {
      populateDataGroupDropdown(value, fullPath);
    }
  });
};

const getFilesInFolder = (structure, path) => {
  const parts = path.split('/');
  let current = structure;
  for (const part of parts) {
    if (current[part]) {
      current = current[part];
    } else {
      return [];
    }
  }
  return current.files || [];
};

const getFileCoupleSeries = (files) => {
  const regex = /^(.+)_(\d{4}-\d{2}-\d{2})_(\d{2}\.\d{2}\.\d{2})\.(EDT|EDX)$/;
  const filePairs = {};

  files.forEach(file => {
    const match = file.name.match(regex);
    if (match) {
      const [, name, date, time, ext] = match;
      const key = `${name}_${date}_${time}`;
      if (!filePairs[key]) filePairs[key] = {};
      filePairs[key][ext] = file;
    }
  });

  return Object.values(filePairs)
    .filter(pair => pair.EDT && pair.EDX)
    .sort((a, b) => a.EDT.name.localeCompare(b.EDT.name));
};

const updateTimeSlider = () => {
  const selectedPath = DOM.selectDataGroup.value;
  const { filesetA, filesetB } = state;

  let fileCoupleSeries = [];

  if (filesetA) {
    const filesA = getFilesInFolder(filesetA.structure, selectedPath);
    fileCoupleSeries = getFileCoupleSeries(filesA);
  }

  if (filesetB) {
    const filesB = getFilesInFolder(filesetB.structure, selectedPath);
    const fileSeriesB = getFileCoupleSeries(filesB);
    fileCoupleSeries = fileCoupleSeries.length > fileSeriesB.length ? fileCoupleSeries : fileSeriesB;
  }

  if (fileCoupleSeries.length > 0) {
    DOM.timeSlider.min = 0;
    DOM.timeSlider.max = fileCoupleSeries.length - 1;
    DOM.timeSlider.value = 0;
    updateTimeLabel(fileCoupleSeries[0].EDT.name);
  } else {
    DOM.timeSlider.min = 0;
    DOM.timeSlider.max = 0;
    DOM.timeSlider.value = 0;
    DOM.timeLabel.innerHTML = '<span style="font-weight: bold;">Time</span> <span style="font-weight: 300;">No valid files</span>';
  }
  updateTimeButtons();
};

const updateTimeLabel = (filename) => {
  const match = filename.match(/_(\d{4}-\d{2}-\d{2})_(\d{2}\.\d{2}\.\d{2})/);
  if (match) {
    const [, date, time] = match;
    DOM.timeLabel.innerHTML = `<span style="font-weight: bold;">Time</span> <span style="font-weight: 300;">${date} - ${time.replace(/\./g, ':')}</span>`;
  } else {
    DOM.timeLabel.innerHTML = '<span style="font-weight: bold;">Time</span> <span style="font-weight: 300;">Invalid format</span>';
  }
};

const getFullPath = (fileset, selectedPath, filename) => {
  return `${fileset.rootDir}/${selectedPath}/${filename}`;
};

const updateTimeButtons = () => {
  DOM.timeDecrementBtn.disabled = parseInt(DOM.timeSlider.value) <= parseInt(DOM.timeSlider.min);
  DOM.timeIncrementBtn.disabled = parseInt(DOM.timeSlider.value) >= parseInt(DOM.timeSlider.max);
};

const incrementTime = () => {
  const currentValue = parseInt(DOM.timeSlider.value);
  const maxValue = parseInt(DOM.timeSlider.max);
  if (currentValue < maxValue) {
    DOM.timeSlider.value = currentValue + 1;
    DOM.timeSlider.dispatchEvent(new Event('input'));
  }
};

const decrementTime = () => {
  const currentValue = parseInt(DOM.timeSlider.value);
  const minValue = parseInt(DOM.timeSlider.min);
  if (currentValue > minValue) {
    DOM.timeSlider.value = currentValue - 1;
    DOM.timeSlider.dispatchEvent(new Event('input'));
  }
};

const handleDataGroupChange = () => {
  updateTimeSlider();
  updateTimeButtons();
  updatePathDisplays();

  // Registra i valori per entrambi i fileset, se presenti
  if (state.filesetA && state.filesetA.edxData) logExtractedValues('filesetA');
  if (state.filesetB && state.filesetB.edxData) logExtractedValues('filesetB');
};

const addEventListeners = () => {
  DOM.buttonFilesetA.addEventListener('click', () => {
    updateFileset('filesetA');
  });

  DOM.buttonFilesetB.addEventListener('click', () => {
    updateFileset('filesetB');
  });

  DOM.selectDataGroup.addEventListener('change', handleDataGroupChange);

  DOM.timeSlider.addEventListener('input', handleTimeSliderInput);

  DOM.timeSlider.addEventListener('change', () => {
    updateTimeButtons();
  });

  DOM.timeIncrementBtn.addEventListener('click', () => {
    incrementTime();
  });

  DOM.timeDecrementBtn.addEventListener('click', () => {
    decrementTime();
  });
};

const handleTimeSliderInput = () => {
  const selectedPath = DOM.selectDataGroup.value;
  const { filesetA, filesetB } = state;

  let selectedCoupleA, selectedCoupleB;

  if (filesetA) {
    const filesA = getFilesInFolder(filesetA.structure, selectedPath);
    const fileSeriesA = getFileCoupleSeries(filesA);
    selectedCoupleA = fileSeriesA[DOM.timeSlider.value];
    if (selectedCoupleA) {
      updateTimeLabel(selectedCoupleA.EDT.name);
    }
  }

  if (filesetB) {
    const filesB = getFilesInFolder(filesetB.structure, selectedPath);
    const fileSeriesB = getFileCoupleSeries(filesB);
    selectedCoupleB = fileSeriesB[DOM.timeSlider.value];
    if (selectedCoupleB && !selectedCoupleA) {
      updateTimeLabel(selectedCoupleB.EDT.name);
    }
  }

  logSelectedFileCouples(selectedPath, selectedCoupleA, selectedCoupleB, filesetA, filesetB);
  updateTimeButtons();

  // Registra i valori per entrambi i fileset, se presenti
  if (state.filesetA && state.filesetA.edxData) logExtractedValues('filesetA');
  if (state.filesetB && state.filesetB.edxData) logExtractedValues('filesetB');
};

const logSelectedFileCouples = (selectedPath, selectedCoupleA, selectedCoupleB, filesetA, filesetB) => {
  console.log('Selected file couples:');

  if (selectedCoupleA) {
    const edtPathA = getFullPath(filesetA, selectedPath, selectedCoupleA.EDT.name);
    const edxPathA = getFullPath(filesetA, selectedPath, selectedCoupleA.EDX.name);
    console.log('Fileset A:');
    console.log(`EDT: ${edtPathA}`);
    console.log(`EDX: ${edxPathA}`);
  } else if (filesetA) {
    console.log('Fileset A: No matching files for this time step');
  }

  if (selectedCoupleB) {
    const edtPathB = getFullPath(filesetB, selectedPath, selectedCoupleB.EDT.name);
    const edxPathB = getFullPath(filesetB, selectedPath, selectedCoupleB.EDX.name);
    console.log('Fileset B:');
    console.log(`EDT: ${edtPathB}`);
    console.log(`EDX: ${edxPathB}`);
  } else if (filesetB) {
    console.log('Fileset B: No matching files for this time step');
  }
};

// Nuove funzioni per il processing dei file EDX

async function processEDXFile(file, filesetKey) {
  try {
    const content = await readFileContent(file);
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(content, "text/xml");

    // Estrai i valori richiesti
    const nrXData = parseInt(xmlDoc.querySelector("nr_xdata").textContent);
    const nrYData = parseInt(xmlDoc.querySelector("nr_ydata").textContent);
    const nrZData = parseInt(xmlDoc.querySelector("nr_zdata").textContent);

    // Estrai e processa le liste di spacing
    const spacingX = processSpacingData(xmlDoc.querySelector("spacing_x").textContent);
    const spacingY = processSpacingData(xmlDoc.querySelector("spacing_y").textContent);
    const spacingZ = processSpacingData(xmlDoc.querySelector("spacing_z").textContent);

    // Memorizza i dati nel fileset appropriato
    state[filesetKey].edxData = {
      nrXData, nrYData, nrZData, spacingX, spacingY, spacingZ
    };

    // Verifica la congruenza se entrambi i fileset sono presenti
    checkCongruence();

    // Log dei valori estratti
    logExtractedValues(filesetKey);
  } catch (error) {
    console.error(`Errore nel processare il file EDX per ${filesetKey}:`, error);
  }
}

function readFileContent(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => resolve(event.target.result);
    reader.onerror = (error) => reject(error);
    reader.readAsText(file);
  });
}

function processSpacingData(spacingString) {
  return spacingString.split(',')
    .map(num => parseFloat(num.trim()))
    .map(num => Number(num.toFixed(2)));
}

function checkCongruence() {
  if (state.filesetA && state.filesetB && state.filesetA.edxData && state.filesetB.edxData) {
    const dataA = state.filesetA.edxData;
    const dataB = state.filesetB.edxData;

    const isCongruent =
      dataA.nrXData === dataB.nrXData &&
      dataA.nrYData === dataB.nrYData &&
      dataA.nrZData === dataB.nrZData &&
      arraysEqual(dataA.spacingX, dataB.spacingX) &&
      arraysEqual(dataA.spacingY, dataB.spacingY) &&
      arraysEqual(dataA.spacingZ, dataB.spacingZ);

    state.isCongruent = isCongruent;
    console.log(`I fileset sono ${isCongruent ? 'congruenti' : 'non congruenti'}`);
  }
}

function arraysEqual(a, b) {
  return a.length === b.length && a.every((val, index) => val === b[index]);
}

function logExtractedValues(filesetKey) {
  const data = state[filesetKey].edxData;
  console.log(`Valori estratti per ${filesetKey}:`);
  console.log(`nr_xdata: ${data.nrXData}`);
  console.log(`nr_ydata: ${data.nrYData}`);
  console.log(`nr_zdata: ${data.nrZData}`);
  console.log(`spacing_x: ${data.spacingX.join(', ')}`);
  console.log(`spacing_y: ${data.spacingY.join(', ')}`);
  console.log(`spacing_z: ${data.spacingZ.join(', ')}`);
}

function findEDXFile(structure) {
  for (const key in structure) {
    if (structure[key] && typeof structure[key] === 'object') {
      if (Array.isArray(structure[key].files)) {
        const edxFile = structure[key].files.find(file => file.name.endsWith('.EDX'));
        if (edxFile) {
          return edxFile;
        }
      }
      const result = findEDXFile(structure[key]);
      if (result) {
        return result;
      }
    }
  }
  return null;
}

const init = () => {
  createPathDisplay();
  populateDataGroupDropdown();
  updateTimeSlider();
  addEventListeners();
};

// Avvia l'inizializzazione quando il DOM è completamente caricato
document.addEventListener('DOMContentLoaded', init);

// Gestione del tema scuro/chiaro
document.addEventListener('DOMContentLoaded', () => {
  const themeSwitcher = document.getElementById('theme-icon');

  // Carica il tema salvato, se esiste
  const currentTheme = localStorage.getItem('theme') || 'light';
  document.body.classList.add(`${currentTheme}-mode`);
  themeSwitcher.classList.add(currentTheme === 'light' ? 'icon-sun' : 'icon-moon');

  themeSwitcher.addEventListener('click', () => {
    const isLight = document.body.classList.contains('light-mode');
    document.body.classList.toggle('light-mode', !isLight);
    document.body.classList.toggle('dark-mode', isLight);
    themeSwitcher.classList.toggle('icon-sun', !isLight);
    themeSwitcher.classList.toggle('icon-moon', isLight);

    // Salva il tema selezionato
    localStorage.setItem('theme', isLight ? 'dark' : 'light');
  });
});