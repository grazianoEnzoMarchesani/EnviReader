if (!('showDirectoryPicker' in window)) {
    console.warn('Questo browser non supporta l\'API File System Access. Alcune funzionalità potrebbero non funzionare correttamente.');
    // Qui potresti implementare un fallback o mostrare un messaggio all'utente
}

function formatSliderLabel(title, value, unit = '') {
    return `
        <span style="font-family: Helvetica, Arial, sans-serif; font-weight: bold;">${title}</span>
        <span style="font-family: Helvetica, Arial, sans-serif; font-weight: 300; font-style: italic; font-size: 0.9em;">${value}${unit}</span>
    `;
}

function updateAllLabels() {
    updateLevelLabel();
    updateSectionXLabel();
    updateSectionYLabel();
    updateWindOpacityLabel();
    updateWindAnimationLabel();
    updateWindDensityLabel();
}

function handleFollowTerrainToggle() {
    const isPressed = DOM.followTerrainToggle.getAttribute('aria-pressed') === 'true';
    DOM.followTerrainToggle.setAttribute('aria-pressed', (!isPressed).toString());
    console.log("Follow terrain:", !isPressed);
    if (!isPressed) {
        Promise.all([loadTerrainData('filesetA'), state.filesetB ? loadTerrainData('filesetB') : Promise.resolve(null)])
            .then(([terrainDataA, terrainDataB]) => {
                if (!terrainDataA && (!state.filesetB || !terrainDataB)) {
                    console.warn("Impossibile caricare i dati del terreno. La funzione 'Follow terrain' potrebbe non funzionare correttamente.");
                    // Opzionale: disattiva il toggle se i dati del terreno non sono disponibili
                    DOM.followTerrainToggle.setAttribute('aria-pressed', 'false');
                }
                updateVisualization('filesetA');
                if (state.filesetB) updateVisualization('filesetB');
            });
    } else {
        updateVisualization('filesetA');
        if (state.filesetB) updateVisualization('filesetB');
    }
}

// Inizializza i riferimenti al DOM e i selettori
function initializeDOMReferences() {
    // Selettori principali
    DOM.followTerrainToggle = safeQuerySelector('#followTerrainToggle');

    DOM.selectDataGroup = safeQuerySelector(SELECTORS.dataGroupSelector);
    DOM.selectData = safeQuerySelector(SELECTORS.dataSelector);
    DOM.buttonFilesetA = safeQuerySelector(SELECTORS.openFilesetA);
    DOM.buttonFilesetB = safeQuerySelector(SELECTORS.openFilesetB);
    DOM.pathDisplayA = document.createElement('div');
    DOM.pathDisplayB = document.createElement('div');

    // Slider e relativi elementi
    DOM.timeSlider = safeQuerySelector(SELECTORS.timeSlider);
    DOM.timeLabel = safeQuerySelector(SELECTORS.sliderTitle);
    DOM.timeIncrementBtn = safeQuerySelector(SELECTORS.incrementTimeBtn);
    DOM.timeDecrementBtn = safeQuerySelector(SELECTORS.decrementTimeBtn);
    DOM.levelSlider = safeQuerySelector(SELECTORS.levelSlider);
    DOM.levelLabel = safeQuerySelector('#levelLabel');
    DOM.sectionXSlider = safeQuerySelector(SELECTORS.sectionXSlider);
    DOM.sectionXLabel = safeQuerySelector('#sectionXLabel');
    DOM.sectionYSlider = safeQuerySelector(SELECTORS.sectionYSlider);
    DOM.sectionYLabel = safeQuerySelector('#sectionYLabel');

    // Contenitori di visualizzazione
    DOM.visualizationContainerA = safeQuerySelector(SELECTORS.visualizationContainerA);
    DOM.visualizationContainerB = safeQuerySelector(SELECTORS.visualizationContainerB);

    // Controlli aggiuntivi
    DOM.followTerrainCheckbox = safeQuerySelector(SELECTORS.followTerrain);
    DOM.colorSchemeSelector = safeQuerySelector(SELECTORS.colorSchemeSelector);
    DOM.windOpacitySlider = safeQuerySelector(SELECTORS.windOpacitySlider);
    DOM.windOpacityLabel = safeQuerySelector('#windOpacityLabel');
    DOM.windAnimationSlider = safeQuerySelector(SELECTORS.windAnimationSlider);
    DOM.windAnimationLabel = safeQuerySelector('#windAnimationLabel');
    DOM.windDensitySlider = safeQuerySelector(SELECTORS.windDensitySlider);
    DOM.windDensityLabel = safeQuerySelector('#windDensityLabel');
    DOM.savePresetButton = safeQuerySelector(SELECTORS.savePresetButton);

    // Log degli elementi trovati e non trovati
    const foundElements = Object.keys(DOM).filter(key => DOM[key] !== null);
    const notFoundElements = Object.keys(DOM).filter(key => DOM[key] === null);

    console.log("Elementi DOM trovati:", foundElements);
    if (notFoundElements.length > 0) {
        console.warn("Elementi DOM non trovati:", notFoundElements);
    }
}




// Funzione di utilità per selezionare elementi DOM in modo sicuro
function safeQuerySelector(selector) {
    const element = document.querySelector(selector);
    if (!element) {
        console.warn(`Elemento non trovato: ${selector}`);
    }
    return element;
}

// Costanti per i selettori
const SELECTORS = {
    dataGroupSelector: '#dataGroupSelector',
    dataSelector: '#dataSelector',
    openFilesetA: '#openFilesetA',
    openFilesetB: '#openFilesetB',
    timeSlider: '#timeSlider',
    sliderTitle: '.slider-title',
    incrementTimeBtn: '.slider-btn[aria-label="Increment time"]',
    decrementTimeBtn: '.slider-btn[aria-label="Decrement time"]',
    levelSlider: '#levelSlider',
    sectionXSlider: '#sectionXSlider',
    sectionYSlider: '#sectionYSlider',
    followTerrain: '#followTerrain',
    colorSchemeSelector: '#colorSchemeSelector',
    windOpacitySlider: '#windOpacitySlider',
    windAnimationSlider: '#windAnimationSlider',
    windDensitySlider: '#windDensitySlider',
    savePresetButton: '#savePreset',
    visualizationContainerA: '#visualizationContainerA',
    visualizationContainerB: '#visualizationContainerB'
};

// Struttura predefinita delle cartelle
const FILE_STRUCTURE = {
    //ENVIObjects: {},
    atmosphere: {},
    biomet: {
        PET: {},
        PMV: {},
        SET: {},
        UTCI: {}
    },
    /* buildings: {
         BPS: {},
         dynamic: {},
         static: {}
     },
     inflow: {},
     inputData: {},
     log: {},*/
    radiation: {},
    receptors: {},
    soil: {},
    solaraccess: {
        // facades: {},
        ground: {},
        //  points: {}
    },
    surface: {}/*,
    vegetation: {
        dynamic: {},
        static: {}
    },
    windsectors: {}*/
};

// Stato dell'applicazionection updateLeve x
let state = {
    filesetA: null,
    filesetB: null,
    currentTimeIndex: 0,
    isCongruent: true,
    edxVariables: [],
    dimensions: { x: 0, y: 0, z: 0 }
};

// Selettori DOM
const DOM = {
    selectDataGroup: safeQuerySelector(SELECTORS.dataGroupSelector),
    selectData: safeQuerySelector(SELECTORS.dataSelector),
    buttonFilesetA: safeQuerySelector(SELECTORS.openFilesetA),
    buttonFilesetB: safeQuerySelector(SELECTORS.openFilesetB),
    pathDisplayA: document.createElement('div'),
    pathDisplayB: document.createElement('div'),
    timeSlider: safeQuerySelector(SELECTORS.timeSlider),
    timeLabel: safeQuerySelector(SELECTORS.sliderTitle),
    timeIncrementBtn: safeQuerySelector(SELECTORS.incrementTimeBtn),
    timeDecrementBtn: safeQuerySelector(SELECTORS.decrementTimeBtn),
    levelSlider: safeQuerySelector(SELECTORS.levelSlider),
    sectionXSlider: safeQuerySelector(SELECTORS.sectionXSlider),
    sectionYSlider: safeQuerySelector(SELECTORS.sectionYSlider),
    visualizationContainerA: safeQuerySelector(SELECTORS.visualizationContainerA),
    visualizationContainerB: safeQuerySelector(SELECTORS.visualizationContainerB),
    followTerrainCheckbox: safeQuerySelector(SELECTORS.followTerrain),
    colorSchemeSelector: safeQuerySelector(SELECTORS.colorSchemeSelector),
    windOpacitySlider: safeQuerySelector(SELECTORS.windOpacitySlider),
    windAnimationSlider: safeQuerySelector(SELECTORS.windAnimationSlider),
    windDensitySlider: safeQuerySelector(SELECTORS.windDensitySlider),
    savePresetButton: safeQuerySelector(SELECTORS.savePresetButton)
};

// Funzioni di utilità
function createPathDisplay() {
    // Crea e aggiunge i display dei percorsi
    DOM.pathDisplayA.className = 'path-display';
    DOM.pathDisplayB.className = 'path-display';
    DOM.buttonFilesetA.insertAdjacentElement('afterend', DOM.pathDisplayA);
    DOM.buttonFilesetB.insertAdjacentElement('afterend', DOM.pathDisplayB);
}

async function handleDirectorySelection() {
    try {
        const dirHandle = await window.showDirectoryPicker();
        const directoryStructure = await buildDirectoryStructure(dirHandle);
        return { structure: directoryStructure, rootDir: dirHandle.name };
    } catch (err) {
        if (err.name !== 'AbortError') {
            console.error('Errore nella selezione della directory:', err);
        }
        return null;
    }
}

async function buildDirectoryStructure(dirHandle) {
    const structure = {};
    for await (const entry of dirHandle.values()) {
        if (entry.kind === 'file') {
            structure.files = structure.files || [];
            structure.files.push(await entry.getFile());
        } else if (entry.kind === 'directory') {
            structure[entry.name] = await buildDirectoryStructure(entry);
        }
    }
    return structure;
}


async function updateFileset(filesetKey) {
    const result = await handleDirectorySelection();
    if (result) {
        state[filesetKey] = result;
        updatePathDisplays();
        console.log(`${filesetKey} directory structure:`, result.structure);

        const edxFile = findEDXFile(result.structure);
        if (edxFile) {
            const edxInfo = await processEDXFile(edxFile, filesetKey);
            state.edxVariables = edxInfo.variableNames;

            const selectedPath = DOM.selectDataGroup.value;
            await updateDataMenu(selectedPath);
        }

        updateTimeSlider();
        updateSliderRanges();
    } else {
        console.log(`${filesetKey} non selezionato`);
    }
}

// Altre funzioni di utilità e gestione degli eventi (mantieni logica originale)
function updatePathDisplay(filesetKey) {
    // Aggiorna il display del percorso per il fileset
    const { rootDir } = state[filesetKey];
    const selectedPath = DOM.selectDataGroup.value;
    const fullPath = `${rootDir}/${selectedPath}`;
    DOM[`pathDisplay${filesetKey.slice(-1)}`].textContent = `Selected path: ${fullPath}`;
}

function updatePathDisplays() {
    // Aggiorna i display dei percorsi per tutti i fileset
    const selectedPath = DOM.selectDataGroup.value;
    ['filesetA', 'filesetB'].forEach(filesetKey => {
        const fileset = state[filesetKey];
        if (fileset) {
            updatePathDisplay(filesetKey);
        }
    });
}

function populateDataGroupDropdown(structure = FILE_STRUCTURE, prefix = '') {
    // Popola il menu a tendina del gruppo dati
    if (!DOM.selectDataGroup) {
        console.error("Elemento select per il gruppo di dati non trovato!");
        return;
    }

    Object.entries(structure).forEach(([key, value]) => {
        const fullPath = prefix ? `${prefix}/${key}` : key;

        const option = document.createElement('option');
        option.value = option.textContent = fullPath;
        DOM.selectDataGroup.appendChild(option);

        if (value && typeof value === 'object' && !Array.isArray(value)) {
            populateDataGroupDropdown(value, fullPath);
        }
    });
}

function getFilesInFolder(structure, path) {
    // Ottiene i file nella cartella specificata
    const parts = path.split('/');
    let current = structure;
    for (const part of parts) {
        if (current[part]) {
            current = current[part];
        } else {
            return [];
        }
    }
    return current.files || [];
}

function getFileCoupleSeries(files) {
    const regex = /^(.+?)_((?:BIO_)?[A-Z]+)_(\d{4}-\d{2}-\d{2})(?:_(\d{2}\.\d{2}\.\d{2}))?\.(EDT|EDX)$/;
    const filePairs = files.reduce((pairs, file) => {
        const match = file.name.match(regex);
        if (match) {
            const [, name, type, date, time, ext] = match;
            const key = time ? `${name}_${type}_${date}_${time}` : `${name}_${type}_${date}`;
            pairs[key] = pairs[key] || {};
            pairs[key][ext.toUpperCase()] = file;
        }
        return pairs;
    }, {});

    return Object.values(filePairs)
        .filter(pair => pair.EDT && pair.EDX)
        .sort((a, b) => {
            const nameA = a.EDT.name.toLowerCase();
            const nameB = b.EDT.name.toLowerCase();
            return nameA.localeCompare(nameB);
        });
}

function updateTimeSlider() {
    // Aggiorna il cursore del tempo
    if (!DOM.selectDataGroup || !DOM.timeSlider || !DOM.timeLabel) {
        console.error("Elementi necessari per updateTimeSlider non trovati!");
        return;
    }

    const selectedPath = DOM.selectDataGroup.value;
    const { filesetA, filesetB } = state;

    let fileCoupleSeries = [];

    if (filesetA) {
        const filesA = getFilesInFolder(filesetA.structure, selectedPath);
        fileCoupleSeries = getFileCoupleSeries(filesA);
    }

    if (filesetB) {
        const filesB = getFilesInFolder(filesetB.structure, selectedPath);
        const fileSeriesB = getFileCoupleSeries(filesB);
        fileCoupleSeries = fileCoupleSeries.length > fileSeriesB.length ? fileCoupleSeries : fileSeriesB;
    }

    if (fileCoupleSeries.length > 0) {
        DOM.timeSlider.min = 0;
        DOM.timeSlider.max = fileCoupleSeries.length - 1;
        DOM.timeSlider.value = 0;
        updateTimeLabel(); // Aggiungi questa linea
    } else {
        DOM.timeSlider.min = 0;
        DOM.timeSlider.max = 0;
        DOM.timeSlider.value = 0;
        DOM.timeLabel.innerHTML = '<span style="font-weight: bold;">Time</span> <span style="font-weight: 300;">No valid files</span>';
    }
    updateTimeButtons();
}

function updateTimeLabel() {
    if (!DOM.timeSlider || !DOM.timeLabel) {
        console.error("Elementi timeSlider o timeLabel non trovati nel DOM");
        return;
    }

    const selectedPath = DOM.selectDataGroup.value;
    const currentTimeIndex = parseInt(DOM.timeSlider.value);
    let fileNameToDisplay = "No valid files";

    const { filesetA, filesetB } = state;
    if (filesetA) {
        const filesA = getFilesInFolder(filesetA.structure, selectedPath);
        const fileSeriesA = getFileCoupleSeries(filesA);
        if (fileSeriesA.length > currentTimeIndex) {
            fileNameToDisplay = fileSeriesA[currentTimeIndex].EDT.name;
        }
    } else if (filesetB) {
        const filesB = getFilesInFolder(filesetB.structure, selectedPath);
        const fileSeriesB = getFileCoupleSeries(filesB);
        if (fileSeriesB.length > currentTimeIndex) {
            fileNameToDisplay = fileSeriesB[currentTimeIndex].EDT.name;
        }
    }

    const regex = /^(.+?)_((?:BIO_)?[A-Z]+)_(\d{4}-\d{2}-\d{2})(?:_(\d{2}\.\d{2}\.\d{2}))?\.(EDT|EDX)$/i;
    const match = fileNameToDisplay.match(regex);
    if (match) {
        const [, , type, date, time] = match;
        let displayText = `${type} ${date}`;
        if (time) {
            displayText += ` - ${time.replace(/\./g, ':')}`;
        }
        DOM.timeLabel.innerHTML = formatSliderLabel('Time', displayText);
    } else {
        DOM.timeLabel.innerHTML = formatSliderLabel('Time', 'Invalid format');
    }
}

function updateTimeLabelText(filename) {
    const match = filename.match(/_(AT|SA)_(\d{4}-\d{2}-\d{2})(?:_(\d{2}\.\d{2}\.\d{2}))?/);
    if (match) {
        const [, type, date, time] = match;
        let displayText = `${type} ${date}`;
        if (time) {
            displayText += ` - ${time.replace(/\./g, ':')}`;
        }
        DOM.timeLabel.innerHTML = `<span style="font-weight: bold;">Time</span> <span style="font-weight: 300;">${displayText}</span>`;
    } else {
        DOM.timeLabel.innerHTML = '<span style="font-weight: bold;">Time</span> <span style="font-weight: 300;">Invalid format</span>';
    }
}

function getFullPath(fileset, selectedPath, filename) {
    // Ottiene il percorso completo del file
    return `${fileset.rootDir}/${selectedPath}/${filename}`;
}

function updateTimeButtons() {
    // Abilita o disabilita i pulsanti di incremento/decremento del tempo
    if (!DOM.timeDecrementBtn || !DOM.timeIncrementBtn || !DOM.timeSlider) {
        console.error("Elementi necessari per updateTimeButtons non trovati!");
        return;
    }
    DOM.timeDecrementBtn.disabled = parseInt(DOM.timeSlider.value) <= parseInt(DOM.timeSlider.min);
    DOM.timeIncrementBtn.disabled = parseInt(DOM.timeSlider.value) >= parseInt(DOM.timeSlider.max);
}

function incrementTime() {
    if (!DOM.timeSlider) {
        console.error("Elemento timeSlider non trovato!");
        return;
    }
    const currentValue = parseInt(DOM.timeSlider.value);
    const maxValue = parseInt(DOM.timeSlider.max);
    if (currentValue < maxValue) {
        DOM.timeSlider.value = currentValue + 1;
        handleTimeSliderChange();
    }
}

function decrementTime() {
    if (!DOM.timeSlider) {
        console.error("Elemento timeSlider non trovato!");
        return;
    }
    const currentValue = parseInt(DOM.timeSlider.value);
    const minValue = parseInt(DOM.timeSlider.min);
    if (currentValue > minValue) {
        DOM.timeSlider.value = currentValue - 1;
        handleTimeSliderChange();
    }
}

async function loadTerrainData(filesetKey) {
    const fileset = state[filesetKey];
    if (!fileset) {
        console.error(`Fileset ${filesetKey} non trovato`);
        return null;
    }

    const selectedPath = 'solaraccess/ground';
    const files = getFilesInFolder(fileset.structure, selectedPath);
    const edtFiles = files.filter(file => file.name.match(/^.*_SA_\d{4}-\d{2}-\d{2}\.EDT$/));

    if (edtFiles.length === 0) {
        console.error(`Nessun file EDT trovato in ${selectedPath}`);
        return null;
    }

    const edtFile = edtFiles[0]; // Prendiamo il primo file EDT

    try {
        const buffer = await edtFile.arrayBuffer();
        const dataView = new DataView(buffer);

        const variableIndex = 3; // L'indice del terreno è la quarta variabile (indice 3)
        const { x: nrXData, y: nrYData } = state.dimensions;
        const totalDataPoints = nrXData * nrYData;
        const bytesPerValue = 4; // Assumendo che i dati siano float a 32 bit

        const terrainData = new Array(totalDataPoints);
        for (let i = 0; i < totalDataPoints; i++) {
            const offset = (variableIndex * totalDataPoints + i) * bytesPerValue;
            terrainData[i] = dataView.getFloat32(offset, true);
        }

        // Log per verificare i dati del terreno
        console.log("Dati del terreno caricati:");
        console.log("Primi 10 valori:", terrainData.slice(0, 10));
        console.log("Ultimi 10 valori:", terrainData.slice(-10));
        console.log("Valore minimo:", Math.min(...terrainData));
        console.log("Valore massimo:", Math.max(...terrainData));

        return terrainData;
    } catch (error) {
        console.error(`Errore nella lettura del file EDT per ${filesetKey}:`, error);
        return null;
    }
}

async function reloadEDXFiles(selectedPath) {
    // Ricarica i file EDX per il percorso selezionato
    const reloadFileset = async (filesetKey) => {
        if (state[filesetKey]) {
            const files = getFilesInFolder(state[filesetKey].structure, selectedPath);
            const fileSeries = getFileCoupleSeries(files);
            if (fileSeries.length > 0) {
                const edxFile = fileSeries[0].EDX;
                const edxInfo = await processEDXFile(edxFile, filesetKey);
                state.edxVariables = edxInfo.variableNames;
                console.log(`File EDX ricaricato per ${filesetKey}`);
            } else {
                console.warn(`Nessun file EDX trovato per ${filesetKey} nel percorso: ${selectedPath}`);
            }
        }
    };

    await Promise.all([reloadFileset('filesetA'), reloadFileset('filesetB')]);
}



async function handleDataGroupChange() {
    const selectedPath = DOM.selectDataGroup.value;

    await reloadEDXFiles(selectedPath);
    await updateDataMenu(selectedPath);

    if (DOM.selectData.options.length > 0) {
        updateTimeSlider();
        updateTimeButtons();
        updatePathDisplays();
        updateSliderRanges();

        if (state.filesetA && state.filesetA.edxData) logExtractedValues('filesetA');
        if (state.filesetB && state.filesetB.edxData) logExtractedValues('filesetB');

        await updateVisualization('filesetA');
        await updateVisualization('filesetB');
    } else {
        console.warn("Nessun dato disponibile per il percorso selezionato.");
        // Puoi aggiungere qui un messaggio per l'utente se lo desideri
    }
}

function isFollowTerrainEnabled() {
    return DOM.followTerrainToggle && DOM.followTerrainToggle.getAttribute('aria-pressed') === 'true';
}

function addEventListeners() {
    // Aggiunge i listener agli eventi
    if (DOM.selectDataGroup) {
        DOM.selectDataGroup.addEventListener('change', handleDataGroupChange);
    }

    if (DOM.buttonFilesetA) {
        DOM.buttonFilesetA.addEventListener('click', () => {
            updateFileset('filesetA');
        });
    }

    if (DOM.buttonFilesetB) {
        DOM.buttonFilesetB.addEventListener('click', () => {
            updateFileset('filesetB');
        });
    }

    if (DOM.timeSlider) {
        DOM.timeSlider.addEventListener('input', handleTimeSliderInput);
        DOM.timeSlider.addEventListener('change', handleTimeSliderChange);
    }
    
    if (DOM.timeIncrementBtn) {
        DOM.timeIncrementBtn.addEventListener('click', incrementTime);
    }

    if (DOM.timeDecrementBtn) {
        DOM.timeDecrementBtn.addEventListener('click', decrementTime);
    }

    if (DOM.selectData) {
        DOM.selectData.addEventListener('change', () => {
            console.log("Variabile selezionata:", DOM.selectData.value);
            updateVisualization('filesetA');
            updateVisualization('filesetB');
        });
    }

    if (DOM.levelSlider) {
        DOM.levelSlider.addEventListener('input', updateLevelLabel);
        DOM.levelSlider.addEventListener('change', handleLevelSliderChange);
    }

    if (DOM.sectionXSlider) {
        DOM.sectionXSlider.addEventListener('input', updateSectionXLabel);
        DOM.sectionXSlider.addEventListener('change', handleSectionXSliderChange);
    }

    if (DOM.sectionYSlider) {
        DOM.sectionYSlider.addEventListener('input', updateSectionYLabel);
        DOM.sectionYSlider.addEventListener('change', handleSectionYSliderChange);
    }

    if (DOM.followTerrainToggle) {
        DOM.followTerrainToggle.addEventListener('click', handleFollowTerrainToggle);
    }

    if (DOM.colorSchemeSelector) {
        DOM.colorSchemeSelector.addEventListener('change', handleColorSchemeChange);
    }

    if (DOM.windOpacitySlider) {
        DOM.windOpacitySlider.addEventListener('input', updateWindOpacityLabel);
        DOM.windOpacitySlider.addEventListener('change', handleWindOpacityChange);
    }

    if (DOM.windAnimationSlider) {
        DOM.windAnimationSlider.addEventListener('input', updateWindAnimationLabel);
        DOM.windAnimationSlider.addEventListener('change', handleWindAnimationChange);
    }

    if (DOM.windDensitySlider) {
        DOM.windDensitySlider.addEventListener('input', updateWindDensityLabel);
        DOM.windDensitySlider.addEventListener('change', handleWindDensityChange);
    }

    if (DOM.savePresetButton) {
        DOM.savePresetButton.addEventListener('click', handleSavePreset);
    }
}

async function handleTimeSliderInput() {
    updateTimeLabel();
    updateTimeButtons();
    await updateVisualization('filesetA');
    await updateVisualization('filesetB');
}

function logSelectedFileCouples(selectedPath, selectedCoupleA, selectedCoupleB, filesetA, filesetB) {
    // Log delle coppie di file selezionate
    console.log('Selected file couples:');

    if (selectedCoupleA) {
        const edtPathA = getFullPath(filesetA, selectedPath, selectedCoupleA.EDT.name);
        const edxPathA = getFullPath(filesetA, selectedPath, selectedCoupleA.EDX.name);
        console.log('Fileset A:');
        console.log(`EDT: ${edtPathA}`);
        console.log(`EDX: ${edxPathA}`);
    } else if (filesetA) {
        console.log('Fileset A: No matching files for this time step');
    }

    if (selectedCoupleB) {
        const edtPathB = getFullPath(filesetB, selectedPath, selectedCoupleB.EDT.name);
        const edxPathB = getFullPath(filesetB, selectedPath, selectedCoupleB.EDX.name);
        console.log('Fileset B:');
        console.log(`EDT: ${edtPathB}`);
        console.log(`EDX: ${edxPathB}`);
    } else if (filesetB) {
        console.log('Fileset B: No matching files for this time step');
    }
}

async function processEDXFile(file, filesetKey) {
    // Processa un file EDX e aggiorna lo stato
    try {
        const content = await readFileContent(file);
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(content, "text/xml");

        const nrXData = parseInt(xmlDoc.querySelector("nr_xdata").textContent);
        const nrYData = parseInt(xmlDoc.querySelector("nr_ydata").textContent);
        const nrZData = parseInt(xmlDoc.querySelector("nr_zdata").textContent);

        const spacingX = processSpacingData(xmlDoc.querySelector("spacing_x").textContent);
        const spacingY = processSpacingData(xmlDoc.querySelector("spacing_y").textContent);
        const spacingZ = processSpacingData(xmlDoc.querySelector("spacing_z").textContent);

        state[filesetKey].edxData = {
            nrXData, nrYData, nrZData, spacingX, spacingY, spacingZ
        };

        // Aggiorna le dimensioni globali
        state.dimensions = { x: nrXData, y: nrYData, z: nrZData };

        checkCongruence();
        logExtractedValues(filesetKey);

        return {
            variableNames: xmlDoc.querySelector("name_variables").textContent.split(',').map(name => name.trim()),
            nrVariables: parseInt(xmlDoc.querySelector("nr_variables").textContent),
            dimensions: { x: nrXData, y: nrYData, z: nrZData }
        };
    } catch (error) {
        console.error(`Errore nel processare il file EDX per ${filesetKey}:`, error);
        throw error;
    }
}

function updateSliderRanges() {
    // Aggiorna i range degli slider
    if (!state.dimensions) {
        console.error("Le dimensioni dei dati non sono disponibili");
        return;
    }

    const { x: nrXData, y: nrYData, z: nrZData } = state.dimensions;

    // Aggiorna il range dello slider Level
    DOM.levelSlider.min = 0;
    DOM.levelSlider.max = nrZData - 1;
    DOM.levelSlider.value = 0; // Inizia da 0

    // Aggiorna il range dello slider Section X
    DOM.sectionXSlider.min = 0;
    DOM.sectionXSlider.max = nrXData - 1;
    DOM.sectionXSlider.value = Math.min(DOM.sectionXSlider.value, nrXData - 1);

    // Aggiorna il range dello slider Section Y
    DOM.sectionYSlider.min = 0;
    DOM.sectionYSlider.max = nrYData - 1;
    DOM.sectionYSlider.value = Math.min(DOM.sectionYSlider.value, nrYData - 1);

    // Aggiorna le etichette degli slider
    updateLevelLabel();
    updateSectionXLabel();
    updateSectionYLabel();
}

function readFileContent(file) {
    // Legge il contenuto di un file
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (event) => {
            const arrayBuffer = event.target.result;
            try {
                const content = new TextDecoder('ISO-8859-1').decode(arrayBuffer);
                if (content.includes('<name_variables>')) {
                    console.log('Codifica utilizzata: ISO-8859-1');
                    resolve(content);
                } else {
                    reject(new Error("Il contenuto del file non sembra essere nel formato atteso"));
                }
            } catch (e) {
                console.error('Errore nella decodifica del file:', e);
                reject(e);
            }
        };
        reader.onerror = (error) => reject(error);
        reader.readAsArrayBuffer(file);
    });
}

function processSpacingData(spacingString) {
    // Processa i dati di spaziatura
    return spacingString.split(',')
        .map(num => parseFloat(num.trim()))
        .map(num => Number(num.toFixed(2)));
}

function checkCongruence() {
    // Verifica la congruenza tra i fileset
    if (state.filesetA && state.filesetB && state.filesetA.edxData && state.filesetB.edxData) {
        const dataA = state.filesetA.edxData;
        const dataB = state.filesetB.edxData;

        const isCongruent =
            dataA.nrXData === dataB.nrXData &&
            dataA.nrYData === dataB.nrYData &&
            dataA.nrZData === dataB.nrZData &&
            arraysEqual(dataA.spacingX, dataB.spacingX) &&
            arraysEqual(dataA.spacingY, dataB.spacingY) &&
            arraysEqual(dataA.spacingZ, dataB.spacingZ);

        state.isCongruent = isCongruent;
        console.log(`I fileset sono ${isCongruent ? 'congruenti' : 'non congruenti'}`);
    }
}

function arraysEqual(a, b) {
    // Confronta due array
    return a.length === b.length && a.every((val, index) => val === b[index]);
}

function logExtractedValues(filesetKey) {
    // Log dei valori estratti dal file EDX
    const data = state[filesetKey].edxData;
    console.log(`Valori estratti per ${filesetKey}:`);
    console.log(`nr_xdata: ${data.nrXData}`);
    console.log(`nr_ydata: ${data.nrYData}`);
    console.log(`nr_zdata: ${data.nrZData}`);
    console.log(`spacing_x: ${data.spacingX.join(', ')}`);
    console.log(`spacing_y: ${data.spacingY.join(', ')}`);
    console.log(`spacing_z: ${data.spacingZ.join(', ')}`);
}

function findEDXFile(structure) {
    if (structure.files) {
        const edxFile = structure.files.find(file => file.name.endsWith('.EDX'));
        if (edxFile) return edxFile;
    }
    for (const key in structure) {
        if (typeof structure[key] === 'object' && !Array.isArray(structure[key])) {
            const result = findEDXFile(structure[key]);
            if (result) return result;
        }
    }
    return null;
}

async function readEDXFile(file) {
    // Legge un file EDX
    const content = await readFileContent(file);
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(content, "text/xml");

    const decodeText = (text) => {
        const textarea = document.createElement('textarea');
        textarea.innerHTML = text;
        return textarea.value;
    };

    const variableNames = xmlDoc.querySelector("name_variables").textContent
        .split(',')
        .map(name => decodeText(name.trim()));

    const nrVariables = parseInt(xmlDoc.querySelector("nr_variables").textContent);
    const dimensions = {
        x: parseInt(xmlDoc.querySelector("nr_xdata").textContent),
        y: parseInt(xmlDoc.querySelector("nr_ydata").textContent),
        z: parseInt(xmlDoc.querySelector("nr_zdata").textContent)
    };

    return { variableNames, nrVariables, dimensions };
}

async function readEDTFile(file, edxInfo, selectedVariable, sliceConfig) {
    const buffer = await file.arrayBuffer();
    const dataView = new DataView(buffer);

    const { dimensions, nrVariables, variableNames } = edxInfo;
    const variableIndex = variableNames.indexOf(selectedVariable);

    if (variableIndex === -1) {
        throw new Error("Selected variable not found in EDX file");
    }

    const sliceData = extractSlice(dataView, dimensions, nrVariables, variableIndex, sliceConfig);

    return sliceData;
}

function extractSlice(dataView, dimensions, nrVariables, variableIndex, sliceConfig) {
    const { level, sectionX, sectionY, terrainData } = sliceConfig;
    const sliceData = [];

    const bytesPerValue = 4; // Assumendo che i dati siano float a 32 bit
    const totalDataPoints = dimensions.x * dimensions.y * dimensions.z;
    const variableOffset = variableIndex * totalDataPoints * bytesPerValue;

    if (level !== null) {
        // Estrai slice orizzontale (XY)
        for (let y = 0; y < dimensions.y; y++) {
            for (let x = 0; x < dimensions.x; x++) {
                let adjustedLevel = level;
                if (terrainData) {
                    const terrainHeight = Math.floor(terrainData[y * dimensions.x + x]);
                    adjustedLevel = terrainHeight + level;

                    // Log per i primi 5 punti
                    if (y < 5 && x < 5) {
                        console.log(`Punto (${x}, ${y}): Terreno = ${terrainHeight}, Level = ${level}, Adjusted = ${adjustedLevel}`);
                    }
                }
                // Assicuriamoci che adjustedLevel non superi il limite superiore
                adjustedLevel = Math.min(adjustedLevel, dimensions.z - 1);

                const offset = variableOffset + ((adjustedLevel * dimensions.y + y) * dimensions.x + x) * bytesPerValue;
                const value = dataView.getFloat32(offset, true);
                sliceData.push(value === -999 ? null : value);
            }
        }
    } else if (sectionX !== null) {
        // Estrai slice verticale (YZ)
        for (let z = 0; z < dimensions.z; z++) {
            for (let y = 0; y < dimensions.y; y++) {
                const offset = variableOffset + ((z * dimensions.y + y) * dimensions.x + sectionX) * bytesPerValue;
                const value = dataView.getFloat32(offset, true);
                sliceData.push(value === -999 ? null : value);
            }
        }
    } else if (sectionY !== null) {
        // Estrai slice verticale (XZ)
        for (let z = 0; z < dimensions.z; z++) {
            for (let x = 0; x < dimensions.x; x++) {
                const offset = variableOffset + ((z * dimensions.y + sectionY) * dimensions.x + x) * bytesPerValue;
                const value = dataView.getFloat32(offset, true);
                sliceData.push(value === -999 ? null : value);
            }
        }
    }

    return sliceData;
}

function populateVariableDropdown(variableNames) {
    // Popola il menu a tendina delle variabili
    const selectElement = DOM.selectData;
    if (!selectElement) {
        console.error(`Elemento select per i dati non trovato!`);
        return;
    }

    selectElement.innerHTML = '';
    variableNames.forEach(name => {
        const option = document.createElement('option');
        option.value = option.textContent = name;
        selectElement.appendChild(option);
    });

    console.log(`Menu a tendina 'Data' aggiornato con nuove variabili.`);
}

async function updateDataMenu(selectedPath) {
    if (!DOM.selectData) {
        console.error("Elemento select per i dati non trovato!");
        return;
    }

    const { filesetA, filesetB } = state;

    let files = [];
    if (filesetA) files = files.concat(getFilesInFolder(filesetA.structure, selectedPath));
    if (filesetB) files = files.concat(getFilesInFolder(filesetB.structure, selectedPath));

    const fileSeries = getFileCoupleSeries(files);
    if (fileSeries.length > 0) {
        const edxFile = fileSeries[0].EDX;
        try {
            const edxInfo = await readEDXFile(edxFile);
            populateVariableDropdown(edxInfo.variableNames);
        } catch (error) {
            console.error(`Errore nella lettura del file EDX: ${error}`);
            DOM.selectData.innerHTML = '<option value="">Errore nella lettura dei dati</option>';
        }
    } else {
        console.warn(`Nessuna coppia di file EDT/EDX valida trovata per il percorso selezionato: ${selectedPath}`);
        DOM.selectData.innerHTML = '<option value="">Nessun dato disponibile</option>';
    }
}

async function handleSectionXSliderChange() {
    // Gestisce il cambio dello slider della sezione X
    await updateVisualization('filesetA');
    await updateVisualization('filesetB');
}

async function handleLevelSliderInput() {
    // Gestisce l'input dello slider del livello
    await updateVisualization('filesetA');
    await updateVisualization('filesetB');
}

async function handleSectionXSliderInput() {
    // Gestisce l'input dello slider della sezione X
    await updateVisualization('filesetA');
    await updateVisualization('filesetB');
}

async function handleSectionYSliderInput() {
    // Gestisce l'input dello slider della sezione Y
    await updateVisualization('filesetA');
    await updateVisualization('filesetB');
}

async function handleFollowTerrainChange() {
    console.log("Follow terrain:", DOM.followTerrainCheckbox.checked);
    if (DOM.followTerrainCheckbox.checked) {
        const terrainDataA = await loadTerrainData('filesetA');
        const terrainDataB = state.filesetB ? await loadTerrainData('filesetB') : null;

        if (!terrainDataA && (!state.filesetB || !terrainDataB)) {
            console.warn("Impossibile caricare i dati del terreno. La funzione 'Follow terrain' potrebbe non funzionare correttamente.");
            // Opzionale: disattiva il checkbox se i dati del terreno non sono disponibili
            DOM.followTerrainCheckbox.checked = false;
        }
    }
    updateVisualization('filesetA');
    if (state.filesetB) updateVisualization('filesetB');
}

function handleColorSchemeChange() {
    // Gestisce il cambio dello schema di colori
    console.log("Color scheme changed:", DOM.colorSchemeSelector.value);
    updateVisualization('filesetA');
    updateVisualization('filesetB');
}

function handleWindOpacityChange() {
    // Gestisce il cambio di opacità del vento
    console.log("Wind opacity:", DOM.windOpacitySlider.value);
    updateVisualization('filesetA');
    updateVisualization('filesetB');
}

function updateSectionXLabel() {
    if (!DOM.sectionXSlider || !DOM.sectionXLabel) {
        console.warn("Elementi sectionXSlider o sectionXLabel non trovati nel DOM");
        return;
    }
    const sectionXValue = DOM.sectionXSlider.value;
    DOM.sectionXLabel.innerHTML = formatSliderLabel('Section X', sectionXValue);
}

function handleWindAnimationChange() {
    // Gestisce il cambio dell'animazione del vento
    console.log("Wind animation:", DOM.windAnimationSlider.value);
    updateVisualization('filesetA');
    updateVisualization('filesetB');
}

function updateWindOpacityLabel() {
    if (!DOM.windOpacitySlider || !DOM.windOpacityLabel) {
        console.warn("Elementi windOpacitySlider o windOpacityLabel non trovati nel DOM");
        return;
    }
    const opacityValue = DOM.windOpacitySlider.value;
    DOM.windOpacityLabel.innerHTML = formatSliderLabel('Wind opacity', opacityValue, '%');
}
function updateLevelLabel() {
    if (!DOM.levelSlider || !DOM.levelLabel) {
        console.warn("Elementi levelSlider o levelLabel non trovati nel DOM");
        return;
    }
    const levelValue = DOM.levelSlider.value;
    DOM.levelLabel.innerHTML = formatSliderLabel('Level', levelValue);
}

function updateSectionYLabel() {
    if (!DOM.sectionYSlider || !DOM.sectionYLabel) {
        console.warn("Elementi sectionYSlider o sectionYLabel non trovati nel DOM");
        return;
    }
    const sectionYValue = DOM.sectionYSlider.value;
    DOM.sectionYLabel.innerHTML = formatSliderLabel('Section Y', sectionYValue);
}


function handleWindDensityChange() {
    // Gestisce il cambio della densità del vento
    console.log("Wind density", DOM.windDensitySlider.value);
    updateVisualization('filesetA');
    updateVisualization('filesetB');
}

async function handleSectionYSliderChange() {
    // Gestisce il cambio dello slider della sezione Y
    await updateVisualization('filesetA');
    await updateVisualization('filesetB');
}

function handleSavePreset() {
    // Gestisce il salvataggio dei preset
    console.log("Saving preset");
    // Implementare la logica per salvare il preset
}

async function handleLevelSliderChange() {
    // Gestisce il cambio dello slider del livello
    await updateVisualization('filesetA');
    await updateVisualization('filesetB');
}

function updateWindDensityLabel() {
    if (!DOM.windDensitySlider || !DOM.windDensityLabel) {
        console.warn("Elementi windDensitySlider o windDensityLabel non trovati nel DOM");
        return;
    }
    const densityValue = DOM.windDensitySlider.value;
    DOM.windDensityLabel.innerHTML = formatSliderLabel('Wind density', densityValue, '%');
}

async function handleTimeSliderChange() {
    updateTimeLabel();
    updateTimeButtons();
    await updateVisualization('filesetA');
    await updateVisualization('filesetB');
}

function updateWindAnimationLabel() {
    if (!DOM.windAnimationSlider || !DOM.windAnimationLabel) {
        console.warn("Elementi windAnimationSlider o windAnimationLabel non trovati nel DOM");
        return;
    }
    const animationValue = DOM.windAnimationSlider.value;
    DOM.windAnimationLabel.innerHTML = formatSliderLabel('Wind animation', animationValue, '%');
}


async function calculateAndVisualizeDifference(selectedVariable, levelSliceConfig, sectionXSliceConfig, sectionYSliceConfig) {
    const filesetA = state.filesetA;
    const filesetB = state.filesetB;
    const selectedPath = DOM.selectDataGroup.value;

    const filesA = getFilesInFolder(filesetA.structure, selectedPath);
    const filesB = getFilesInFolder(filesetB.structure, selectedPath);
    const fileSeriesA = getFileCoupleSeries(filesA);
    const fileSeriesB = getFileCoupleSeries(filesB);

    if (fileSeriesA.length > 0 && fileSeriesB.length > 0) {
        const currentTimeIndex = parseInt(DOM.timeSlider.value);
        const edtFileA = fileSeriesA[currentTimeIndex].EDT;
        const edtFileB = fileSeriesB[currentTimeIndex].EDT;
        const edxInfoA = await readEDXFile(fileSeriesA[currentTimeIndex].EDX);
        const edxInfoB = await readEDXFile(fileSeriesB[currentTimeIndex].EDX);

        if (edtFileA && edtFileB && edxInfoA && edxInfoB) {
            const levelSliceDataA = await readEDTFile(edtFileA, edxInfoA, selectedVariable, levelSliceConfig);
            const levelSliceDataB = await readEDTFile(edtFileB, edxInfoB, selectedVariable, levelSliceConfig);
            const sectionXSliceDataA = await readEDTFile(edtFileA, edxInfoA, selectedVariable, sectionXSliceConfig);
            const sectionXSliceDataB = await readEDTFile(edtFileB, edxInfoB, selectedVariable, sectionXSliceConfig);
            const sectionYSliceDataA = await readEDTFile(edtFileA, edxInfoA, selectedVariable, sectionYSliceConfig);
            const sectionYSliceDataB = await readEDTFile(edtFileB, edxInfoB, selectedVariable, sectionYSliceConfig);

            const levelDiffData = calculateDifference(levelSliceDataA, levelSliceDataB);
            const sectionXDiffData = calculateDifference(sectionXSliceDataA, sectionXSliceDataB);
            const sectionYDiffData = calculateDifference(sectionYSliceDataA, sectionYSliceDataB);

            visualizeData(levelDiffData, state.dimensions, levelSliceConfig, selectedVariable, 'level', 'filesetDiff');
            visualizeData(sectionXDiffData, state.dimensions, sectionXSliceConfig, selectedVariable, 'section-x', 'filesetDiff');
            visualizeData(sectionYDiffData, state.dimensions, sectionYSliceConfig, selectedVariable, 'section-y', 'filesetDiff');
        }
    }
}

async function updateVisualization(filesetKey) {
    const selectedVariable = DOM.selectData.value;
    const level = parseInt(DOM.levelSlider.value);
    const sectionX = parseInt(DOM.sectionXSlider.value);
    const sectionY = parseInt(DOM.sectionYSlider.value);
    const selectedPath = DOM.selectDataGroup.value;
    const followTerrain = DOM.followTerrainToggle && DOM.followTerrainToggle.getAttribute('aria-pressed') === 'true';    const fileset = state[filesetKey];
    if (!fileset) {
        console.log(`Fileset ${filesetKey} non caricato`);
        return;
    }

    let edtFile, edxInfo;
    const files = getFilesInFolder(fileset.structure, selectedPath);
    const fileSeries = getFileCoupleSeries(files);
    if (fileSeries.length > 0) {
        const currentTimeIndex = parseInt(DOM.timeSlider.value);
        edtFile = fileSeries[currentTimeIndex].EDT;
        edxInfo = await readEDXFile(fileSeries[currentTimeIndex].EDX);
    }

    if (edtFile && edxInfo) {
        const { x: nrXData, y: nrYData, z: nrZData } = state.dimensions;

        let terrainData = null;
        if (followTerrain) {
            terrainData = await loadTerrainData(filesetKey);
            if (terrainData) {
                console.log("Dati del terreno caricati per la visualizzazione:",
                    "Primi 5 valori:", terrainData.slice(0, 5));
            } else {
                console.warn(`Impossibile caricare i dati del terreno per ${filesetKey}. La visualizzazione procederà senza seguire il terreno.`);
            }
        }

        const levelSliceConfig = { level, sectionX: null, sectionY: null, terrainData };
        const sectionXSliceConfig = { level: null, sectionX: Math.min(sectionX, nrXData - 1), sectionY: null };
        const sectionYSliceConfig = { level: null, sectionX: null, sectionY: Math.min(sectionY, nrYData - 1) };

        const levelSliceData = await readEDTFile(edtFile, edxInfo, selectedVariable, levelSliceConfig);
        const sectionXSliceData = await readEDTFile(edtFile, edxInfo, selectedVariable, sectionXSliceConfig);
        const sectionYSliceData = await readEDTFile(edtFile, edxInfo, selectedVariable, sectionYSliceConfig);

        visualizeData(levelSliceData, state.dimensions, levelSliceConfig, selectedVariable, 'level', filesetKey);
        visualizeData(sectionXSliceData, state.dimensions, sectionXSliceConfig, selectedVariable, 'section-x', filesetKey);
        visualizeData(sectionYSliceData, state.dimensions, sectionYSliceConfig, selectedVariable, 'section-y', filesetKey);

        // Calcola e visualizza la differenza se entrambi i fileset sono caricati
        if (state.filesetA && state.filesetB && filesetKey === 'filesetB') {
            calculateAndVisualizeDifference(selectedVariable, levelSliceConfig, sectionXSliceConfig, sectionYSliceConfig);
        }
    } else {
        console.error(`File EDT o informazioni EDX non disponibili per ${filesetKey}`);
    }
}

function calculateDifference(dataA, dataB) {
    return dataA.map((valueA, index) => {
        const valueB = dataB[index];
        if (valueA === null || valueB === null) {
            return null;
        }
        return valueA - valueB;
    });
}

function visualizeData(sliceData, dimensions, sliceConfig, variableName, viewType, filesetKey) {
    const { level, sectionX, sectionY } = sliceConfig;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    let width, height;
    if (level !== null) {
        width = dimensions.x;
        height = dimensions.y;
    } else if (sectionX !== null) {
        width = dimensions.y;
        height = dimensions.z;
    } else if (sectionY !== null) {
        width = dimensions.x;
        height = dimensions.z;
    }

    canvas.width = width;
    canvas.height = height;

    const validData = sliceData.filter(value => value !== null);
    const minValue = Math.min(...validData);
    const maxValue = Math.max(...validData);

    const imageData = ctx.createImageData(width, height);
    for (let i = 0; i < sliceData.length; i++) {
        const value = sliceData[i];
        if (value === null) {
            imageData.data[i * 4] = 128;
            imageData.data[i * 4 + 1] = 128;
            imageData.data[i * 4 + 2] = 128;
            imageData.data[i * 4 + 3] = 100;
        } else {
            let normalizedValue, r, g, b;
            if (filesetKey === 'filesetDiff') {
                // Use a diverging color scale for difference visualization
                normalizedValue = (value - minValue) / (maxValue - minValue);
                if (normalizedValue < 0.5) {
                    // Blue to white
                    r = Math.floor(normalizedValue * 2 * 255);
                    g = Math.floor(normalizedValue * 2 * 255);
                    b = 255;
                } else {
                    // White to red
                    r = 255;
                    g = Math.floor((1 - normalizedValue) * 2 * 255);
                    b = Math.floor((1 - normalizedValue) * 2 * 255);
                }
            } else {
                // Use the original grayscale for Fileset A and B
                const colorValue = Math.floor(((value - minValue) / (maxValue - minValue)) * 255);
                r = g = b = colorValue;
            }
            imageData.data[i * 4] = r;
            imageData.data[i * 4 + 1] = g;
            imageData.data[i * 4 + 2] = b;
            imageData.data[i * 4 + 3] = 255;
        }
    }
    ctx.putImageData(imageData, 0, 0);

    let containerSelector;
    if (filesetKey === 'filesetDiff') {
        containerSelector = `#visualizationContainerDiff .chart-container.${viewType}`;
    } else {
        containerSelector = `#visualizationContainer${filesetKey.slice(-1)} .chart-container.${viewType}`;
    }
    const visualizationContainer = document.querySelector(containerSelector);
    if (visualizationContainer) {
        visualizationContainer.innerHTML = '';
        visualizationContainer.appendChild(canvas);

        const infoDiv = document.createElement('div');
        infoDiv.textContent = `${variableName}, Min: ${minValue.toFixed(2)}, Max: ${maxValue.toFixed(2)}, Null values: ${sliceData.filter(v => v === null).length}`;
        visualizationContainer.appendChild(infoDiv);
    } else {
        console.error(`Container non trovato per la vista ${viewType} del ${filesetKey}. Selector: ${containerSelector}`);
    }
}
function handleDataChange() {
    // Gestisce il cambio dei dati selezionati
    updateVisualization('filesetA');
    updateVisualization('filesetB');
}


function initSidebarToggle() {
    const toggleButton = document.getElementById('toggle-sidebar');
    const container = document.querySelector('.container');

    toggleButton.addEventListener('click', () => {
        container.classList.toggle('sidebar-hidden');
        container.classList.toggle('sidebar-visible');
        updateButtonRotation();

        // Aggiorniamo immediatamente il layout
        handleResize();

        // Aggiungiamo un piccolo ritardo per assicurarci che la transizione sia completa
        setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
        }, 300);
    });
}

function updateButtonRotation() {
    const container = document.querySelector('.container');
    const toggleButton = document.getElementById('toggle-sidebar');
    const toggleIcon = toggleButton.querySelector('.material-icons');
    const isMobile = window.innerWidth <= 768;
    const isSidebarVisible = !container.classList.contains('sidebar-hidden');

    if (isMobile) {
        if (isSidebarVisible) {
            toggleIcon.style.transform = 'rotate(90deg)'; // Punta verso l'alto
        } else {
            toggleIcon.style.transform = 'rotate(-90deg)'; // Punta verso il basso
        }
    } else {
        toggleIcon.style.transform = isSidebarVisible ? 'rotate(0deg)' : 'rotate(180deg)';
    }
}


function handleResize() {
    const container = document.querySelector('.container');
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    const isMobile = window.innerWidth <= 768;
    const isSidebarVisible = !container.classList.contains('sidebar-hidden');

    if (isMobile) {
        sidebar.style.height = '300px';
        sidebar.style.width = '100%';
        mainContent.style.marginTop = isSidebarVisible ? '300px' : '0';
        mainContent.style.marginLeft = '0';
    } else {
        sidebar.style.height = '100%';
        sidebar.style.width = '300px';
        mainContent.style.marginTop = '0';
        mainContent.style.marginLeft = isSidebarVisible ? '300px' : '0';
    }

    updateButtonRotation();
}
// Inizializzazione
function init() {
    initializeDOMReferences();
    createPathDisplay();

    if (DOM.selectDataGroup) {
        populateDataGroupDropdown();
        // Imposta un valore predefinito per Data Group
        DOM.selectDataGroup.value = DOM.selectDataGroup.options[0].value;
    } else {
        console.error("Elemento select per il gruppo di dati non trovato durante l'inizializzazione!");
    }

    if (DOM.timeSlider && DOM.selectDataGroup) {
        updateTimeSlider();
    } else {
        console.error("Elementi necessari per updateTimeSlider non trovati durante l'inizializzazione!");
    }

    addEventListeners();

    // Inizializza il menu Data in base al valore predefinito di Data Group
    initializeDataMenu();

    // Inizializza i range degli slider
    updateSliderRanges();
    initSidebarToggle();
    handleResize();
    window.addEventListener('resize', handleResize);

    // Aggiungiamo la classe sidebar-visible all'inizio se la sidebar non è nascosta
    const container = document.querySelector('.container');
    if (!container.classList.contains('sidebar-hidden')) {
        container.classList.add('sidebar-visible');
    }

    // Aggiorna tutte le etichette dopo che il DOM è completamente caricato
    updateAllLabels();

    if (DOM.followTerrainToggle) {
        DOM.followTerrainToggle.setAttribute('aria-pressed', 'false');
    }
    
}

async function initializeDataMenu() {
    // Inizializza il menu dei dati
    if (!DOM.selectDataGroup || !DOM.selectData) {
        console.error("Elementi select necessari non trovati!");
        return;
    }

    const selectedPath = DOM.selectDataGroup.value;
    await updateDataMenu(selectedPath);
}

document.addEventListener('DOMContentLoaded', init);

// Gestione del tema scuro/chiaro
document.addEventListener('DOMContentLoaded', () => {
    const themeSwitcher = document.getElementById('theme-icon');

    // Carica il tema salvato, se esiste
    const currentTheme = localStorage.getItem('theme') || 'light';
    document.body.classList.add(`${currentTheme}-mode`);
    themeSwitcher.classList.add(currentTheme === 'light' ? 'icon-sun' : 'icon-moon');

    themeSwitcher.addEventListener('click', () => {
        const isLight = document.body.classList.contains('light-mode');
        document.body.classList.toggle('light-mode', !isLight);
        document.body.classList.toggle('dark-mode', isLight);
        themeSwitcher.classList.toggle('icon-sun', !isLight);
        themeSwitcher.classList.toggle('icon-moon', isLight);

        // Salva il tema selezionato
        localStorage.setItem('theme', isLight ? 'dark' : 'light');
    });
});